package ServerAPI.objects;

import android.os.Parcel;
import android.os.Parcelable;

public class Person implements Parcelable {

    private String id;
    private String name;

    public Person() {
        id = "";
        name = "";
    }

    public Person(String personIdParam, String nameParam) {
        id = personIdParam;
        name = nameParam;
    }

    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Id: " + id + " Name: " + name;
    }

    protected Person(Parcel in) {
        id = in.readString();
        name = in.readString();
    }

    public static final Creator<Person> CREATOR = new Creator<Person>() {
        @Override
        public Person createFromParcel(Parcel in) {
            return new Person(in);
        }

        @Override
        public Person[] newArray(int size) {
            return new Person[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(name);
    }

    @Override
    public boolean equals(Object obj) {
        if(obj instanceof Person)
        {
            Person otherPerson = (Person) obj;
            if (!otherPerson.getName().equals(this.getName())){
                return false;
            }

            if (!otherPerson.getId().equals(this.getId())) {
                return false;
            }

            return true;
        }
        else
        {
            return false;
        }
    }
}