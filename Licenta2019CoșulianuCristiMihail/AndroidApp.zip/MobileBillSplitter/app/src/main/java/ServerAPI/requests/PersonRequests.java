package ServerAPI.requests;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import com.example.mobilebillsplitter.adapters.PersonsAdapter;
import com.example.mobilebillsplitter.utils.PreferencesController;

import java.util.List;

import ServerAPI.MBSServerApi;
import ServerAPI.ClientBuilder;
import ServerAPI.objects.Person;
import ServerAPI.responses.MessageResponse;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PersonRequests {

    private Context context;
    private MBSServerApi service;

    public PersonRequests(Context context) {
        this.context = context;
        service = ClientBuilder.createService();
    }

    public void getPersonById(final String personId) {

        Call<Person> call = service.getPersonById(personId);

        call.enqueue(new Callback<Person>() {
            @Override
            public void onResponse(Call<Person> call, Response<Person> response) {
                Person responsePerson = response.body();
                Toast.makeText(context, "Response person: " + responsePerson.getId() + "  " + responsePerson.getName(), Toast.LENGTH_LONG).show();

            }

            @Override
            public void onFailure(Call<Person> call, Throwable t) {
                Toast.makeText(context, "Error when getting person with id: " + personId, Toast.LENGTH_LONG).show();
            }
        });
    }

    public void getPersonByName(final String personName, final PersonsAdapter personsAdapter) {

        Call<Person> call = service.getPersonByName(personName);

        call.enqueue(new Callback<Person>() {
            @Override
            public void onResponse(Call<Person> call, Response<Person> response) {
                Person responsePerson = response.body();
                if (responsePerson != null) {
                    personsAdapter.add(responsePerson);
                    personsAdapter.notifyDataSetChanged();
                } else {
                    Toast.makeText(context, "No user found with this name!", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<Person> call, Throwable t) {
                Toast.makeText(context, "Error when getting person with id: " + personName, Toast.LENGTH_LONG).show();
            }
        });
    }

    public void postPersonByName(final String personName) {

        Call<Person> call = service.postPersonByName(personName);

        call.enqueue(new Callback<Person>() {
            @Override
            public void onResponse(Call<Person> call, Response<Person> response) {
                Person responsePerson = response.body();
                if (responsePerson != null) {
                    // NOTIFY THAT YOU GOT THE USER AND LOG HIM IN.
                    PreferencesController.addUser(context, responsePerson);
                    Toast.makeText(context, "You are logged in now!", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(context, "Username is already used!", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<Person> call, Throwable t) {
                Toast.makeText(context, "Username is already used!" , Toast.LENGTH_LONG).show();
            }
        });
    }

    public void deletePerson(final String personName) {

        Call<MessageResponse> call = service.deletePersonByName(personName);

        call.enqueue(new Callback<MessageResponse>() {
            @Override
            public void onResponse(Call<MessageResponse> call, Response<MessageResponse> response) {
                MessageResponse responsePerson = response.body();
                if (responsePerson != null) {
                    // NOTIFY THAT YOU GOT THE USER AND LOG HIM IN.
                    PreferencesController.removeUser(context);
                    Toast.makeText(context, "Username deleted!", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(context, "No user found with this name!", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<MessageResponse> call, Throwable t) {
                Toast.makeText(context, "No user found with this name!" , Toast.LENGTH_LONG).show();
            }
        });
    }

    public void getAllPersons() {

        Call<List<Person>> call = service.getAllPersons();

        call.enqueue(new Callback<List<Person>>() {
            @Override
            public void onResponse(Call<List<Person>> call, Response<List<Person>> response) {
                List<Person> personList = response.body();
                Log.v("PERSONS_LIST", "" + personList);
                Toast.makeText(context, "Response person: " + personList, Toast.LENGTH_LONG).show();
            }

            @Override
            public void onFailure(Call<List<Person>> call, Throwable t) {
                Toast.makeText(context, "Error when getting persons" , Toast.LENGTH_LONG).show();
            }
        });
    }


}
