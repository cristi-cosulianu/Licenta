package ServerAPI.requests;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.webkit.MimeTypeMap;
import android.widget.Toast;

import java.io.File;
import java.util.List;

import ServerAPI.utils.FileUtils;
import ServerAPI.MBSServerApi;
import ServerAPI.ClientBuilder;
import ServerAPI.objects.Bill;
import ServerAPI.objects.Payment;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class SendImageRequest {

    private Activity initialActivity;
    private Class destinationClass;

    private Context context;

    public SendImageRequest(Context context, Activity initialActivity, Class destinationClass) {
        this.context = context;
        this.initialActivity = initialActivity;
        this.destinationClass = destinationClass;
    }

    public void uploadFile(Uri fileUri) {
        // create upload service client
        MBSServerApi service =
                ClientBuilder.createService();

        // https://github.com/iPaulPro/aFileChooser/blob/master/aFileChooser/src/com/ipaulpro/afilechooser/utils/FileUtils.java
        // use the FileUtils to get the actual file by uri
        File file = FileUtils.getFile(context, fileUri);

        // create RequestBody instance from file
        RequestBody requestFile =
                RequestBody.create(
                        MediaType.parse(getMimeType(fileUri.toString())),
                        file
                );

        // MultipartBody.Part is used to send also the actual file name
        MultipartBody.Part body =
                MultipartBody.Part.createFormData("billImage", file.getName(), requestFile);

        // add another part within the multipart request
        String descriptionString = "hello, this is description speaking";
        RequestBody description =
                RequestBody.create(
                        okhttp3.MultipartBody.FORM, descriptionString);

        // finally, execute the request
//        Call<ResponseBody> call = service.uploadImage(description, body);
        Call<List<Payment>> call = service.uploadImage(body);

        call.enqueue(new Callback<List<Payment>>() {
            @Override
            public void onResponse(Call<List<Payment>> call,
                                   Response<List<Payment>> response) {
                List<Payment> paymentList = response.body();
                Log.v("Upload", "success: " + paymentList);

                Bill bill = new Bill();
                for (Payment payment : paymentList) {
                    bill.addPayment(payment);
                }

                Intent intent = new Intent(initialActivity, destinationClass);
                Bundle billBundle = bill.createBillBundle(context);
                intent.putExtras(billBundle);

                context.startActivity(intent);
            }

            @Override
            public void onFailure(Call<List<Payment>> call, Throwable t) {
                Log.e("Upload error:", t.getMessage());
                Toast.makeText(context, "Upload error, try again please!", Toast.LENGTH_LONG).show();
            }
        });
    }

    public static String getMimeType(String url) {
        String type = null;
        String extension = MimeTypeMap.getFileExtensionFromUrl(url);
        if (extension != null) {
            type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
        }
        return type;
    }
}
