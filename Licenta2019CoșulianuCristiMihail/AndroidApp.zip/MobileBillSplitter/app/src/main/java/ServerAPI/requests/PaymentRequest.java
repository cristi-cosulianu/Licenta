package ServerAPI.requests;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.example.mobilebillsplitter.UI.LoadingView;
import com.example.mobilebillsplitter.activities.AssignPaymentsActivity;

import java.util.List;

import ServerAPI.ClientBuilder;
import ServerAPI.MBSServerApi;
import ServerAPI.objects.Bill;
import ServerAPI.objects.Bills;
import ServerAPI.objects.Payment;
import ServerAPI.objects.PaymentToPerson;
import ServerAPI.objects.Person;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PaymentRequest {
    private Context context;
    private MBSServerApi service;

    public PaymentRequest(Context context) {
        this.context = context;
        service = ClientBuilder.createService();
    }

    public void putPaymentPayer(List<PaymentToPerson> paymentToPersonList, final Intent intent, final LoadingView loadingView){
        loadingView.show();

        Call<Bill> call = service.putPaymentsPayers(paymentToPersonList);

        call.enqueue(new Callback<Bill>() {
            @Override
            public void onResponse(Call<Bill> call, Response<Bill> response) {
                Bill responseBill = response.body();
                Bundle billBundle = responseBill.createBillBundle(context);
                intent.putExtras(billBundle);
                context.startActivity(intent);
                loadingView.dismiss();
                Toast.makeText(context, "We posted your selection!", Toast.LENGTH_LONG).show();
            }

            @Override
            public void onFailure(Call<Bill> call, Throwable t) {
                loadingView.dismiss();
                Toast.makeText(context, "Error while getting the new bill!", Toast.LENGTH_LONG).show();
            }
        });
    }

    public void putPaymentPayer(List<PaymentToPerson> paymentToPersonList, final AssignPaymentsActivity instance, final View view){

        Call<Bill> call = service.putPaymentsPayers(paymentToPersonList);

        call.enqueue(new Callback<Bill>() {
            @Override
            public void onResponse(Call<Bill> call, Response<Bill> response) {
                instance.requestPayment(view);
                Toast.makeText(context, "We posted your selection!", Toast.LENGTH_LONG).show();
            }

            @Override
            public void onFailure(Call<Bill> call, Throwable t) {
                Toast.makeText(context, "Error while getting the new bill!", Toast.LENGTH_LONG).show();
            }
        });
    }
}
