package ServerAPI.objects;

import android.content.Context;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;

import com.example.mobilebillsplitter.R;

import java.util.ArrayList;
import java.util.List;

public class Bill implements Parcelable {

    private List<Payment> paymentsList;
    private List<Person> personsList;
    private List<PaymentToPerson> paymentToPersonList;
    private String billTitle;
    private Person initiator;
    private String billId;

    public List<Payment> getPaymentsList() {
        return paymentsList;
    }

    public List<Person> getPersonsList() {
        return personsList;
    }

    public List<PaymentToPerson> getPaymentToPersonList() {
        return paymentToPersonList;
    }

    public String getBillTitle() {
        return billTitle;
    }

    public Person getInitiator() {
        return initiator;
    }

    public String getBillId() {
        return billId;
    }

//    public String getInitiatorId() {
//        return initiator.getId();
//    }


    public void setPaymentsList(List<Payment> paymentsList) {
        this.paymentsList = paymentsList;
    }

    public void setPersonsList(List<Person> personsList) {
        this.personsList = personsList;
    }

    public void setPaymentToPersonList(List<PaymentToPerson> paymentToPersonList) {
        this.paymentToPersonList = paymentToPersonList;
    }

    public void setBillTitle(String billTitle) {
        this.billTitle = billTitle;
    }

    public void setInitiator(Person initiator) {
        this.initiator = initiator;
    }

    public void setBillId(String billId) {
        this.billId = billId;
    }

//    public void setInitiatorId(String initiatorId) {
//        this.initiator.setId(initiatorId);
//    }

    public void addPayment(Payment payment) {
        if (payment != null) {
            paymentsList.add(payment);
        }
    }

    public void addPerson(Person person) {
        if (person != null) {
            personsList.add(person);
        }
    }

    public void addPaymentToPerson(PaymentToPerson paymentToPerson) {
        if (paymentToPerson != null) {
            paymentToPersonList.add(paymentToPerson);
        }
    }

    public boolean existPaymentToPerson(Payment payment, Person person) {
        PaymentToPerson paymentToPerson = new PaymentToPerson(payment, person);
        return (paymentToPersonList.indexOf(paymentToPerson) >= 0);
    }

    public boolean existPaymentInPaymentsToPerson(Payment payment) {
        for (int i = 0; i < paymentToPersonList.size(); i++){
            if (paymentToPersonList.get(i).getPayment().equals(payment)) {
                return true;
            }
        }
        return false;
    }

    public Person getPersonForPaymentInPaymentsToPerson(Payment payment) {
        for (int i = 0; i < paymentToPersonList.size(); i++) {
            if (paymentToPersonList.get(i).getPayment().equals(payment)) {
                return paymentToPersonList.get(i).getPerson();
            }
        }
        return null;
    }

    public boolean existPersonInPaymentsToPerson(Person person) {
        for (int i = 0; i < paymentToPersonList.size(); i++){
            if (paymentToPersonList.get(i).getPerson().equals(person)) {
                return true;
            }
        }
        return false;
    }

    public void removePaymentToPerson(PaymentToPerson paymentToPerson) {
        if (paymentToPerson != null) {
            paymentToPersonList.remove(paymentToPerson);
        }
    }

    public void removePayment(Payment payment) {
        if (payment != null) {
            paymentsList.remove(payment);
        }
    }

    public void removePerson(Person person) {
        if (person != null) {
            personsList.remove(person);
        }
    }

    public Bill() {
        paymentsList = new ArrayList<>();
        personsList = new ArrayList<>();
        paymentToPersonList = new ArrayList<>();
        billTitle = "";
        initiator = new Person();
        billId = "";
    }

    public Bill(String billTitleParam) {
        paymentsList = new ArrayList<>();
        personsList = new ArrayList<>();
        paymentToPersonList = new ArrayList<>();
        billTitle = billTitleParam;
        initiator = new Person();
        billId = "";
    }

    public Bill(List<Payment> paymentsListParam, List<Person> personsListParam, String billTitleParam) {
        paymentsList = new ArrayList<>(paymentsListParam);
        personsList = new ArrayList<>(personsListParam);
        paymentToPersonList = new ArrayList<>();
        billTitle = billTitleParam;
        initiator = new Person();
        billId = "";
    }

    public Bill(List<Payment> paymentsListParam,
                List<Person> personsListParam,
                List<PaymentToPerson> paymentToPersonListParam,
                String billTitleParam,
                Person initiatorParam,
                String billIdParam) {
        paymentsList = new ArrayList<>(paymentsListParam);
        personsList = new ArrayList<>(personsListParam);
        paymentToPersonList = new ArrayList<>(paymentToPersonListParam);
        billTitle = billTitleParam;
        initiator = initiatorParam;
        billId = billIdParam;
    }

    protected Bill(Parcel in) {
        paymentsList = in.createTypedArrayList(Payment.CREATOR);
        personsList = in.createTypedArrayList(Person.CREATOR);
        paymentToPersonList = in.createTypedArrayList(PaymentToPerson.CREATOR);
        billTitle = in.readString();
        initiator = in.readTypedObject(Person.CREATOR);
        billId = in.readString();

    }

    public static final Creator<Bill> CREATOR = new Creator<Bill>() {
        @Override
        public Bill createFromParcel(Parcel in) {
            return new Bill(in);
        }

        @Override
        public Bill[] newArray(int size) {
            return new Bill[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeTypedList(paymentsList);
        dest.writeTypedList(personsList);
        dest.writeTypedList(paymentToPersonList);
        dest.writeString(billTitle);
        dest.writeTypedObject(initiator, flags);
        dest.writeString(billId);
    }

    public Bundle createBillBundle(Context context) {
        String billKey = context.getResources().getString(R.string.EXTRA_BILL_KEY);
        Bundle bundle = new Bundle();
        bundle.putParcelable(billKey, this);
        return bundle;
    }

}
