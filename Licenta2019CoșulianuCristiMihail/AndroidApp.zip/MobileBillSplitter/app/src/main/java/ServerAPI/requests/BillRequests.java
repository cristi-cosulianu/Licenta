package ServerAPI.requests;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import com.example.mobilebillsplitter.UI.LoadingView;
import com.example.mobilebillsplitter.activities.BillMainActivity;
import com.example.mobilebillsplitter.services.OnBillUpdatedComplete;
import com.example.mobilebillsplitter.utils.PreferencesController;

import java.util.List;

import ServerAPI.ClientBuilder;
import ServerAPI.MBSServerApi;
import ServerAPI.objects.Bill;
import ServerAPI.objects.Bills;
import ServerAPI.objects.Person;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BillRequests {

    private Context context;
    private MBSServerApi service;

    public BillRequests(Context context) {
        this.context = context;
        service = ClientBuilder.createService();
    }

    public void getBill(final String billId, final Intent intent) {

        Call<Bill> call = service.getBillById(billId);

        call.enqueue(new Callback<Bill>() {
            @Override
            public void onResponse(Call<Bill> call, Response<Bill> response) {
                Bill responseBill = response.body();

                Person person = PreferencesController.getPersonLoggedIn(context);
                responseBill.addPerson(person);
                Bundle billBundle = responseBill.createBillBundle(context);
                intent.putExtras(billBundle);
                context.startActivity(intent);
                Toast.makeText(context, "We got the bill!", Toast.LENGTH_LONG).show();
            }

            @Override
            public void onFailure(Call<Bill> call, Throwable t) {
                Toast.makeText(context, "Error while getting the new bill!", Toast.LENGTH_LONG).show();
            }
        });
    }

    public void getBill(final String billId, final Intent intent, final LoadingView loadingView) {
        loadingView.show();

        Call<Bill> call = service.getBillById(billId);

        call.enqueue(new Callback<Bill>() {
            @Override
            public void onResponse(Call<Bill> call, Response<Bill> response) {
                Bill responseBill = response.body();
                Bundle billBundle = responseBill.createBillBundle(context);
                Person person = PreferencesController.getPersonLoggedIn(context);
                if (!responseBill.getInitiator().equals(person)) {
                    intent.putExtras(billBundle);
                    context.startActivity(intent);
                    Toast.makeText(context, "We got the bill!", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(context, "You are the initiator, you can not join!", Toast.LENGTH_LONG).show();
                }
                loadingView.dismiss();

            }

            @Override
            public void onFailure(Call<Bill> call, Throwable t) {
                loadingView.dismiss();
                Toast.makeText(context, "Error while getting the new bill!", Toast.LENGTH_LONG).show();
            }
        });
    }

    public void getBill(final String billId, final OnBillUpdatedComplete listener) {

        Call<Bill> call = service.getBillById(billId);

        call.enqueue(new Callback<Bill>() {
            @Override
            public void onResponse(Call<Bill> call, Response<Bill> response) {
                listener.onBillUpdateComplete(response.body());
                Toast.makeText(context, "List updated!", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(Call<Bill> call, Throwable t) {
                Toast.makeText(context, "Error while updating!", Toast.LENGTH_LONG).show();
            }
        });
    }

    public void getPaymentsByPersonId(final String personId, final Intent intent, final LoadingView loadingView) {
        loadingView.show();

        Call<Bills> call = service.getPaymentsByPersonId(personId);

        call.enqueue(new Callback<Bills>() {
            @Override
            public void onResponse(Call<Bills> call, Response<Bills> response) {
                Bills responseBills = response.body();
                Bundle billsBundle = responseBills.createBillsBundle(context);
                intent.putExtras(billsBundle);
                context.startActivity(intent);
                loadingView.dismiss();
                Toast.makeText(context, "We got the payments!", Toast.LENGTH_LONG).show();
            }

            @Override
            public void onFailure(Call<Bills> call, Throwable t) {
                loadingView.dismiss();
                Toast.makeText(context, "Error while getting the new bill!", Toast.LENGTH_LONG).show();
            }
        });
    }

    public void getBillsByInitiator(final String initiatorId, final Intent intent, final LoadingView loadingView) {
        loadingView.show();

        Call<Bills> call = service.getBillsByInitiatorId(initiatorId);

        call.enqueue(new Callback<Bills>() {
            @Override
            public void onResponse(Call<Bills> call, Response<Bills> response) {
                Bills responseBills = response.body();
                Bundle billsBundle = responseBills.createBillsBundle(context);
                intent.putExtras(billsBundle);
                context.startActivity(intent);
                loadingView.dismiss();
                Toast.makeText(context, "We got the bill!", Toast.LENGTH_LONG).show();
            }

            @Override
            public void onFailure(Call<Bills> call, Throwable t) {
                loadingView.dismiss();
                Toast.makeText(context, "Error while getting the new bill!", Toast.LENGTH_LONG).show();
            }
        });
    }

    public void postNewBill(final Bill bill, final Intent intent, final LoadingView loadingView) {

        loadingView.show();

        Call<Bill> call = service.postBill(bill);

        call.enqueue(new Callback<Bill>() {
            @Override
            public void onResponse(Call<Bill> call, Response<Bill> response) {
                Bill responseBill = response.body();
                Bundle billBundle = responseBill.createBillBundle(context);
                intent.putExtras(billBundle);
                context.startActivity(intent);
                loadingView.dismiss();
            }

            @Override
            public void onFailure(Call<Bill> call, Throwable t) {
                Toast.makeText(context, "Error while posting the new bill!", Toast.LENGTH_LONG).show();
                loadingView.dismiss();
            }
        });
    }

    public void updateBill(final Bill bill, final Intent intent) {

        Call<Bill> call = service.postBill(bill);

        call.enqueue(new Callback<Bill>() {
            @Override
            public void onResponse(Call<Bill> call, Response<Bill> response) {
                Bill responseBill = response.body();
                Bundle billBundle = responseBill.createBillBundle(context);
                intent.putExtras(billBundle);
                context.startActivity(intent);
            }

            @Override
            public void onFailure(Call<Bill> call, Throwable t) {
                Toast.makeText(context, "Error while posting the new bill!", Toast.LENGTH_LONG).show();
            }
        });
    }
}
