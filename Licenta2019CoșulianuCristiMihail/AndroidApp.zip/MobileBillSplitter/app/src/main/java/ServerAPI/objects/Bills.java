package ServerAPI.objects;

import android.content.Context;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;

import com.example.mobilebillsplitter.R;

import java.util.ArrayList;
import java.util.List;

public class Bills implements Parcelable {

    private List<Bill> bills;

    public List<Bill> getBills() {
        return bills;
    }

    public void setBills(List<Bill> bills) {
        this.bills = bills;
    }

    public Bills() {
        bills = new ArrayList<>();
    }

    protected Bills(Parcel in) {
        bills = in.createTypedArrayList(Bill.CREATOR);
    }

    public static final Creator<Bills> CREATOR = new Creator<Bills>() {
        @Override
        public Bills createFromParcel(Parcel in) {
            return new Bills(in);
        }

        @Override
        public Bills[] newArray(int size) {
            return new Bills[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeTypedList(bills);
    }

    public Bundle createBillsBundle(Context context) {
        String billsKey = context.getResources().getString(R.string.EXTRA_BILLS_KEY);
        Bundle bundle = new Bundle();
        bundle.putParcelable(billsKey, this);
        return bundle;
    }

}
