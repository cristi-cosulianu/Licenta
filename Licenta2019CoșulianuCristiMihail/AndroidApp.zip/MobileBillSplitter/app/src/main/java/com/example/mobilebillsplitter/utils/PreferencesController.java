package com.example.mobilebillsplitter.utils;

import android.content.Context;
import android.content.SharedPreferences;

import com.example.mobilebillsplitter.R;

import java.util.ArrayList;
import java.util.List;

import ServerAPI.objects.Person;

public class PreferencesController {

    public static void clearPreferences(Context context) {
        String preference_file = context.getString(R.string.preferences_file);
        SharedPreferences sharedPreferences = context.getSharedPreferences(preference_file, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();
    }

    public static int getSelectedPerson(Context context) {
        String preference_file = context.getString(R.string.preferences_file);
        SharedPreferences sharedPreferences = context.getSharedPreferences(preference_file, Context.MODE_PRIVATE);
        return sharedPreferences.getInt(context.getString(R.string.SELECTED_PERSON), -1);
    }

    public static boolean isPersonSelected(Context context) {
        String preference_file = context.getString(R.string.preferences_file);
        SharedPreferences sharedPreferences = context.getSharedPreferences(preference_file, Context.MODE_PRIVATE);
        return (sharedPreferences.getInt(context.getString(R.string.SELECTED_PERSON), -1) != -1);
    }

    public static void saveSelectedPerson(Context context, int selectedPerson) {
        String preference_file_name = context.getString(R.string.preferences_file);
        SharedPreferences sharedPreferences = context.getSharedPreferences(preference_file_name, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(context.getString(R.string.SELECTED_PERSON), selectedPerson);
        editor.apply();
    }

    public static void removeSelectedPerson(Context context) {
        String preference_file_name = context.getString(R.string.preferences_file);
        SharedPreferences sharedPreferences = context.getSharedPreferences(preference_file_name, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.remove(context.getString(R.string.SELECTED_PERSON));
        editor.apply();
    }

    public static List<Integer> getSelectedPayments(Context context, int numberOfPayments) {
        List<Integer> paymentsArray = new ArrayList<>();
        String preference_file = context.getString(R.string.preferences_file);
        SharedPreferences sharedPreferences = context.getSharedPreferences(preference_file, Context.MODE_PRIVATE);
        for (int index = 0; index < numberOfPayments; index++) {
            if (sharedPreferences.getInt(context.getString(R.string.SELECTED_PAYMENT) + index, -1) >= 0) {
                paymentsArray.add(index);
            }
        }
        return paymentsArray;
    }

    public static boolean isPaymentSelected(Context context, int numberOfPayments, int paymentIndex) {
        String preference_file = context.getString(R.string.preferences_file);
        SharedPreferences sharedPreferences = context.getSharedPreferences(preference_file, Context.MODE_PRIVATE);
        for (int index = 0; index < numberOfPayments; index++) {
            if (sharedPreferences.getInt(context.getString(R.string.SELECTED_PAYMENT) + index, -1) >= 0) {
                if (paymentIndex == index) {
                    return true;
                }
            }
        }
        return false;
    }

    public static void saveSelectedPayment(Context context, int selectedPayment) {
        String preference_file_name = context.getString(R.string.preferences_file);
        SharedPreferences sharedPreferences = context.getSharedPreferences(preference_file_name, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(context.getString(R.string.SELECTED_PAYMENT) + selectedPayment, selectedPayment);
        editor.apply();
    }

    public static void removeSelectedPayment(Context context, int selectedPayment) {
        String preference_file_name = context.getString(R.string.preferences_file);
        SharedPreferences sharedPreferences = context.getSharedPreferences(preference_file_name, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.remove(context.getString(R.string.SELECTED_PAYMENT) + selectedPayment);
        editor.apply();
    }

    public static boolean isLoggedIn(Context context) {
        String pref_account_file_name = context.getString(R.string.account_file);
        SharedPreferences sharedPreferences = context.getSharedPreferences(pref_account_file_name, Context.MODE_PRIVATE);
        return (sharedPreferences.getString(context.getString(R.string.USERNAME_KEY), null) != null);
    }

    public static String getUserLoggedIn(Context context) {
        String pref_account_file_name = context.getString(R.string.account_file);
        SharedPreferences sharedPreferences = context.getSharedPreferences(pref_account_file_name, Context.MODE_PRIVATE);
        return (sharedPreferences.getString(context.getString(R.string.USERNAME_KEY), null));
    }

    public static Person getPersonLoggedIn(Context context) {
        String pref_account_file_name = context.getString(R.string.account_file);
        SharedPreferences sharedPreferences = context.getSharedPreferences(pref_account_file_name, Context.MODE_PRIVATE);
        String username = (sharedPreferences.getString(context.getString(R.string.USERNAME_KEY), null));
        String user_id = (sharedPreferences.getString(context.getString(R.string.USER_ID_KEY), null));
        return new Person(user_id, username);
    }

    public static void addUser(Context context, Person person) {
        String pref_account_file_name = context.getString(R.string.account_file);
        SharedPreferences sharedPreferences = context.getSharedPreferences(pref_account_file_name, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(context.getString(R.string.USERNAME_KEY), person.getName());
        editor.putString(context.getString(R.string.USER_ID_KEY), person.getId());

        editor.apply();
    }

    public static void removeUser(Context context) {
        String pref_account_file_name = context.getString(R.string.account_file);
        SharedPreferences sharedPreferences = context.getSharedPreferences(pref_account_file_name, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.remove(context.getString(R.string.USERNAME_KEY));
        editor.remove(context.getString(R.string.USER_ID_KEY));

        editor.apply();
    }
}
