package com.example.mobilebillsplitter.activities;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.example.mobilebillsplitter.R;
import com.example.mobilebillsplitter.adapters.PaymentStatusAdapter;
import com.example.mobilebillsplitter.interfaces.OnDataReceive;
import com.example.mobilebillsplitter.services.BillUpdateTask;
import com.example.mobilebillsplitter.services.GooglePay;
import com.example.mobilebillsplitter.services.OnBillUpdatedComplete;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.wallet.AutoResolveHelper;
import com.google.android.gms.wallet.IsReadyToPayRequest;
import com.google.android.gms.wallet.PaymentData;
import com.google.android.gms.wallet.PaymentDataRequest;
import com.google.android.gms.wallet.PaymentsClient;
import com.google.android.gms.wallet.Wallet;
import com.google.android.gms.wallet.WalletConstants;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;
import java.util.Optional;

import ServerAPI.objects.Bill;
import ServerAPI.objects.Payment;
import ServerAPI.objects.Person;
import ServerAPI.requests.PaymentRequest;

public class BillStatusActivity extends AppCompatActivity implements OnDataReceive, OnBillUpdatedComplete {
    private PaymentStatusAdapter listAdapter;
    private ListView listView;
    private Button homeButton;
    private Button mGooglePayButton;
    private PaymentsClient mPaymentsClient;
    private BillUpdateTask billUpdateTask;


    private Bill bill;


    /** A constant integer you define to track a request for payment data activity */
    private static final int LOAD_PAYMENT_DATA_REQUEST_CODE = 42;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_bill_status);

        getSupportActionBar().setTitle("Bill status page");

        getIntentData();

//        initializeBill();

        initializeListView();

        initializeHomeButton();

        initializeGooglePayButton();


    }

    private void initializeGooglePayButton() {
        mGooglePayButton = findViewById(R.id.googlePayButtonID);
        mGooglePayButton.setBackgroundResource(R.drawable.ic_google_pay);

        mPaymentsClient =
                Wallet.getPaymentsClient(
                        this,
                        new Wallet.WalletOptions.Builder()
                                .setEnvironment(WalletConstants.ENVIRONMENT_TEST)
                                .build());
        possiblyShowGooglePayButton();

    }

    private void initializeHomeButton() {
        homeButton = findViewById(R.id.billStatusHomeButtonID);
        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BillStatusActivity.this, MainActivity.class);
                Bundle billBundle = bill.createBillBundle(getApplicationContext());
                intent.putExtras(billBundle);
                startActivity(intent);
            }
        });
    }

    private void getIntentData() {
        Bundle bundle = getIntent().getExtras();
        String billKey = getApplicationContext().getResources().getString(R.string.EXTRA_BILL_KEY);
        bill = bundle.getParcelable(billKey);
    }

    private void initializeListView() {
        listAdapter = new PaymentStatusAdapter(this, bill);
        listView = findViewById(R.id.personsStatusListViewID);
        listView.setAdapter(listAdapter);
        listAdapter.notifyDataSetChanged();
    }
    @Override
    public void OnDataReceive(List<Person> personList) {

    }

    /**
     * Determine the viewer's ability to pay with a payment method supported by your app and display a
     * Google Pay payment button
     *
     * @see <a
     *     href="https://developers.google.com/android/reference/com/google/android/gms/wallet/PaymentsClient#isReadyToPay(com.google.android.gms.wallet.IsReadyToPayRequest)">PaymentsClient#IsReadyToPay</a>
     */
    private void possiblyShowGooglePayButton() {
        final Optional<JSONObject> isReadyToPayJson = GooglePay.getIsReadyToPayRequest();
        if (!isReadyToPayJson.isPresent()) {
            return;
        }
        IsReadyToPayRequest request = IsReadyToPayRequest.fromJson(isReadyToPayJson.get().toString());
        if (request == null) {
            return;
        }
        Task<Boolean> task = mPaymentsClient.isReadyToPay(request);
        task.addOnCompleteListener(
                new OnCompleteListener<Boolean>() {
                    @Override
                    public void onComplete(@NonNull Task<Boolean> task) {
                        try {
                            boolean result = task.getResult(ApiException.class);
                            if (result) {
                                // show Google as a payment option
                                mGooglePayButton = findViewById(R.id.googlePayButtonID);
                                mGooglePayButton.setOnClickListener(
                                        new View.OnClickListener() {
                                            @Override
                                            public void onClick(View view) {
                                                requestPayment(view);
                                            }
                                        });
                                mGooglePayButton.setVisibility(View.VISIBLE);
                            }
                        } catch (ApiException exception) {
                            // handle developer errors
                        }
                    }
                });
    }

    /**
     * Display the Google Pay payment sheet after interaction with the Google Pay payment button
     *
     * @param view optionally uniquely identify the interactive element prompting for payment
     */
    public void requestPayment(View view) {
        Optional<JSONObject> paymentDataRequestJson = GooglePay.getPaymentDataRequestFor(getTotalBillSum().toString());
        if (!paymentDataRequestJson.isPresent()) {
            return;
        }
        PaymentDataRequest request =
                PaymentDataRequest.fromJson(paymentDataRequestJson.get().toString());
        if (request != null) {
            AutoResolveHelper.resolveTask(
                    mPaymentsClient.loadPaymentData(request), this, LOAD_PAYMENT_DATA_REQUEST_CODE);
        }
    }

    /**
     * Handle a resolved activity from the Google Pay payment sheet
     *
     * @param requestCode the request code originally supplied to AutoResolveHelper in
     *     requestPayment()
     * @param resultCode the result code returned by the Google Pay API
     * @param data an Intent from the Google Pay API containing payment or error data
     * @see <a href="https://developer.android.com/training/basics/intents/result">Getting a result
     *     from an Activity</a>
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            // value passed in AutoResolveHelper
            case LOAD_PAYMENT_DATA_REQUEST_CODE:
                switch (resultCode) {
                    case Activity.RESULT_OK:
                        PaymentData paymentData = PaymentData.getFromIntent(data);
                        String json = paymentData.toJson();
                        // if using gateway tokenization, pass this token without modification
                        JSONObject paymentMethodData = null;
                        String paymentToken = null;
                        try {
                            paymentMethodData = new JSONObject(json)
                                    .getJSONObject("paymentMethodData");

                            paymentToken = paymentMethodData.getJSONObject("tokenizationData").getString("token");
                            Toast.makeText(getApplicationContext(), "You are done here!", Toast.LENGTH_LONG).show();
                            Intent intent = new Intent(BillStatusActivity.this, MainActivity.class);
                            startActivity(intent);
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(getApplicationContext(), "error", Toast.LENGTH_LONG).show();

                        }

                        break;
                    case Activity.RESULT_CANCELED:
                        Toast.makeText(getApplicationContext(), "canceled", Toast.LENGTH_LONG).show();
                        break;
                    case AutoResolveHelper.RESULT_ERROR:
                        Status status = AutoResolveHelper.getStatusFromIntent(data);
                        Toast.makeText(getApplicationContext(), "" + status, Toast.LENGTH_LONG).show();
                        // Log the status for debugging.
                        // Generally, there is no need to show an error to the user.
                        // The Google Pay payment sheet will present any account errors.
                        break;
                    default:
                        // Do nothing.
                }
                break;
            default:
                // Do nothing.
        }
    }

    @Override
    public void onBillUpdateComplete(Bill bill) {
        this.bill = bill;
        listAdapter.notifyDataSetChanged();
    }

    private Float getTotalBillSum() {
        Float totalSum = 0.0f;
        List<Payment> paymentList = bill.getPaymentsList();
        for (int i = 0; i < paymentList.size(); i++) {
            Payment payment = paymentList.get(i);
            totalSum += payment.getProductPrice();
        }
        return totalSum;
    }

    @Override
    protected void onPause() {
        billUpdateTask.StopTimer();
        Log.d("TASK", "CANCELED");
        super.onPause();
    }

    @Override
    protected void onStart() {
        billUpdateTask = new BillUpdateTask(this);
        billUpdateTask.execute(bill);
        Log.d("TASK", "STARTED");
        super.onStart();
    }

    @Override
    protected void onStop() {
        billUpdateTask.StopTimer();
        Log.d("TASK", "CANCELED");
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        billUpdateTask.StopTimer();
        Log.d("TASK", "CANCELED");
        super.onDestroy();
    }
}