package com.example.mobilebillsplitter.activities;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mobilebillsplitter.adapters.PersonsAdapter;
import com.example.mobilebillsplitter.services.BillUpdateTask;
import com.example.mobilebillsplitter.services.OnBillUpdatedComplete;
import com.example.mobilebillsplitter.utils.PreferencesController;
import com.example.mobilebillsplitter.R;

import java.util.ArrayList;
import java.util.List;

import ServerAPI.objects.Bill;
import ServerAPI.objects.Payment;
import ServerAPI.objects.Person;
import ServerAPI.requests.BillRequests;

public class PersonsActivity extends AppCompatActivity implements OnBillUpdatedComplete {

    private TextView billIdView;

    private Button doneAddingButton;

    private ListView listView;

    private PersonsAdapter listAdapter;

    private Bill bill;

    private SwipeRefreshLayout swipeRefreshLayout;

    private BillUpdateTask billUpdateTask;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_persons);

        getSupportActionBar().setTitle("Add persons page");

        // For tests.
//        initializeBills();

        // Functie care sa verifice daca s-au alaturat noi persoane.

        // Uncomment this after tests.
        getIntentData();

        initializeBillIdView();

        initializeListView();

        initializeDoneButton();

    }

    private void initializeBillIdView() {
        billIdView = findViewById(R.id.billIdTextViewID);
        String billIdText = getApplicationContext().getResources().getString(R.string.share_bill_text);
        billIdText += " " + bill.getBillId();
        billIdView.setText(billIdText);
    }

    private void initializeListView() {
        listAdapter = new PersonsAdapter(this, bill);
        listView = findViewById(R.id.addPersonsListViewID);
        listView.setAdapter(listAdapter);

        initializeSwipeToRefresh();
    }

    private void initializeSwipeToRefresh() {
        swipeRefreshLayout = findViewById(R.id.refreshPersonsWidget);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                checkBillForUpdates();
            }
        });
    }

    private void checkBillForUpdates() {
//        Intent intent = new Intent(MainActivity.this, MainActivity.class);
        Intent intent = new Intent(PersonsActivity.this, PersonsActivity.class);
        BillRequests billRequests = new BillRequests(getApplicationContext());
        billRequests.getBill(bill.getBillId(), intent);
    }

    private void getIntentData() {
        Bundle bundle = getIntent().getExtras();
        String billKey = getApplicationContext().getResources().getString(R.string.EXTRA_BILL_KEY);
        bill = bundle.getParcelable(billKey);
    }

    private void initializeDoneButton() {
        doneAddingButton = findViewById(R.id.addPersonsDoneButtonID);
        doneAddingButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (updateBillObject()) {
//                    Intent intent = new Intent(MainActivity.this, AssignPaymentsActivity.class);
                    Intent intent = new Intent(PersonsActivity.this, AssignPaymentsActivity.class);
                    Bundle billBundle = bill.createBillBundle(getApplicationContext());
                    PreferencesController.saveSelectedPerson(getApplicationContext(), 0);
                    intent.putExtras(billBundle);
                    startActivity(intent);
                }

            }
        });
    }


    private boolean updateBillObject() {
        List<Person> listOfPersons = listAdapter.getListOfPersons();
        if (listOfPersons != null && listOfPersons.size() > 0) {
            bill.setPersonsList(listOfPersons);
            return true;
        } else {
            Toast.makeText(getApplicationContext(), "Please add one person!", Toast.LENGTH_LONG).show();
            return false;
        }
    }

    @Override
    public void onBillUpdateComplete(Bill bill) {
        this.bill = bill;
        listAdapter.notifyDataSetChanged();
    }

    @Override
    protected void onStart() {
        super.onStart();
//        billUpdateTask = new BillUpdateTask(this);
//        billUpdateTask.execute(bill);
        overridePendingTransition(0, 0);
    }

    @Override
    protected void onPause() {
        super.onPause();
//        billUpdateTask.StopTimer();
        overridePendingTransition(0, 0);
    }

    @Override
    protected void onStop() {
        super.onStop();
//        billUpdateTask.StopTimer();

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
//        billUpdateTask.StopTimer();
    }
}