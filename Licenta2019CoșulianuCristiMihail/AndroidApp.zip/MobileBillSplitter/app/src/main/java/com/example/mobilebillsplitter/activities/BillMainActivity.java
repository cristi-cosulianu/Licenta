package com.example.mobilebillsplitter.activities;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.ListView;

import com.example.mobilebillsplitter.R;
import com.example.mobilebillsplitter.UI.LoadingView;
import com.example.mobilebillsplitter.adapters.BillMainAdapter;
import com.example.mobilebillsplitter.modular_layouts.NavigationButtons;
import com.example.mobilebillsplitter.utils.PreferencesController;

import java.util.ArrayList;
import java.util.List;

import ServerAPI.objects.Bill;
import ServerAPI.objects.Bills;
import ServerAPI.objects.Payment;
import ServerAPI.objects.Person;
import ServerAPI.requests.BillRequests;

public class BillMainActivity extends AppCompatActivity {

    private ListView billsView;
    private BillMainAdapter billsAdapter;

    private Bills bills;

    private LoadingView loadingView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_bill_main);

        getSupportActionBar().setTitle("Bill Activity");

        initializeLoadingView();
        getIntentData();
        initializeBillsListView();
        initializeNavigation();
    }

    private void initializeNavigation() {
        NavigationButtons navigationButtons = new NavigationButtons();
        navigationButtons.initialize(getApplicationContext(), BillMainActivity.this, loadingView);
    }

    private void initializeLoadingView() {
        loadingView = new LoadingView(this);
    }

    private void getIntentData() {
        Bundle bundle = getIntent().getExtras();
        String billKey = getApplicationContext().getResources().getString(R.string.EXTRA_BILLS_KEY);
        bills = new Bills();
        bills = bundle.getParcelable(billKey);
    }


    private void initializeBillsListView() {
        billsAdapter = new BillMainAdapter(this, bills);
        billsView = findViewById(R.id.billsListViewID);
        billsView.setAdapter(billsAdapter);
        billsAdapter.notifyDataSetChanged();
    }

}
