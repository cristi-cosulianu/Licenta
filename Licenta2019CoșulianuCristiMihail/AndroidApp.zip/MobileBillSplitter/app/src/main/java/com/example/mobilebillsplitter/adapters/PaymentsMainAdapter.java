package com.example.mobilebillsplitter.adapters;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.mobilebillsplitter.R;
import com.example.mobilebillsplitter.activities.AssignPaymentsActivity;
import com.example.mobilebillsplitter.utils.PreferencesController;

import java.util.List;

import ServerAPI.objects.Bill;
import ServerAPI.objects.Bills;
import ServerAPI.objects.Person;

public class PaymentsMainAdapter extends ArrayAdapter {

    private Activity context;
    private List<Bill> bills;

    public PaymentsMainAdapter(Activity contextParam, Bills billParam) {
        super(contextParam, R.layout.row_payment_main, billParam.getBills());
        context = contextParam;
        bills = billParam.getBills();
        for (int i = 0; i < bills.size(); i++) {
            Person person = PreferencesController.getPersonLoggedIn(getContext());
            if (bills.get(i).getInitiator().equals(person)) {
                bills.remove(i);
                i--;
            }
        }
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.row_payment_main, null, true);
        final TextView titleTextView = rowView.findViewById(R.id.rowPaymentTitleID);
        final TextView dateTextView = rowView.findViewById(R.id.rowPaymentDateID);
        final TextView personsNumberTextView = rowView.findViewById(R.id.rowBillInitiatorID);

        titleTextView.setText(bills.get(position).getBillTitle());
        dateTextView.setText(bills.get(position).getBillTitle());
        personsNumberTextView.setText(bills.get(position).getInitiator().getName());

        rowView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String sourceKey = context.getResources().getString(R.string.SOURCE_CLASS);
                Bundle billBundle = bills.get(position).createBillBundle(context);
                Intent intent = new Intent(context, AssignPaymentsActivity.class);
                intent.putExtras(billBundle);
                intent.putExtra(sourceKey, "PaymentsMainActivity");
                context.startActivity(intent);
            }
        });


        return rowView;
    }
}
