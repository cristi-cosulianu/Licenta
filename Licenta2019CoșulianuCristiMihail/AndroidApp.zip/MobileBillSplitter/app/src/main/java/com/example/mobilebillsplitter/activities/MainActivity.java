package com.example.mobilebillsplitter.activities;

import ServerAPI.objects.Bill;
import ServerAPI.objects.Payment;
import ServerAPI.objects.Person;
import ServerAPI.requests.BillRequests;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.StrictMode;

import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mobilebillsplitter.UI.LoadingView;
import com.example.mobilebillsplitter.adapters.PersonsAdapter;
import com.example.mobilebillsplitter.services.GoogleVision;
import com.example.mobilebillsplitter.utils.PreferencesController;
import com.example.mobilebillsplitter.R;
import com.example.mobilebillsplitter.modular_layouts.NavigationButtons;
import com.theartofdev.edmodo.cropper.CropImage;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    Button addBillButton, joinBillButton;

    LoadingView loadingView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        PreferencesController.clearPreferences(getApplicationContext());

        setContentView(R.layout.activity_main);

        getSupportActionBar().setTitle("Mobile Bill Splitter");

        initializeAddBillButton();
        initializeJoinButton();
        initializeLoadingView();
        initializeNavigation();

    }

    private void initializeLoadingView() {
        loadingView = new LoadingView(this);
    }

    private void initializeNavigation() {
        NavigationButtons navigationButtons = new NavigationButtons();
        navigationButtons.initialize(getApplicationContext(), MainActivity.this, loadingView);
    }

    public void initializeAddBillButton() {
        addBillButton = findViewById(R.id.mainAddBillButtonID);
        addBillButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (PreferencesController.isLoggedIn(getApplicationContext())) {
                    // Strict mode to take photo.
                    // @link: https://developer.android.com/reference/android/os/StrictMode.VmPolicy.Builder
                    StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
                    StrictMode.setVmPolicy(builder.build());

                    CropImage.activity().start(MainActivity.this);

                } else {
                    Toast.makeText(getApplicationContext(), "You should log in first in setting page!", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    public void initializeJoinButton() {
        joinBillButton = findViewById(R.id.mainJoinBillButtonID);
        joinBillButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (PreferencesController.isLoggedIn(getApplicationContext())) {
                    Bill bill = new Bill();
                    Intent intent = new Intent(MainActivity.this, JoinBillActivity.class);
                    Bundle billBundle = bill.createBillBundle(getApplicationContext());
                    intent.putExtras(billBundle);
                    getApplicationContext().startActivity(intent);

                } else {
                    Toast.makeText(getApplicationContext(), "You should log in first in setting page!", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    public void add_gradient(View v)
    {
        Button btn = (Button) findViewById(R.id.mainAddBillButtonID);

        //Color.parseColor() method allow us to convert
        // a hexadecimal color string to an integer value (int color)
        int[] colors = {Color.parseColor("#008000"), Color.parseColor("#FF0000"), Color.parseColor("#ADFF2F")};

        //create a new gradient color
        GradientDrawable gd = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM, colors);

        gd.setCornerRadius(0f);
        //apply the button background to newly created drawable gradient
        btn.setBackground(gd);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK) {
//                Uri resultUri = result.getUri();
//                SendImageRequest sendImageRequest = new SendImageRequest(getApplicationContext(), this, EditResultsActivity.class);
//                sendImageRequest.uploadFile(resultUri);
                Bitmap bitmapImage = getBitmap(result.getUri());
                GoogleVision googleVision = new GoogleVision(getApplicationContext(), MainActivity.this, EditResultsActivity.class);
                googleVision.runTextRecognition(bitmapImage, loadingView);

            } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                Exception error = result.getError();
                Toast.makeText(this, "" + error, Toast.LENGTH_LONG).show();
            }
        }
    }

    private Bitmap getBitmap(Uri bitmapUri) {
        Bitmap bitmapImage = null;
        try {
            InputStream image_stream;
            image_stream = getApplicationContext().getContentResolver().openInputStream(bitmapUri);
            bitmapImage = BitmapFactory.decodeStream(image_stream);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bitmapImage;
    }


}