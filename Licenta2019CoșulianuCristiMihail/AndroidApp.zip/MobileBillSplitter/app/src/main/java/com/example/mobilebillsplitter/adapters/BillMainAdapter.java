package com.example.mobilebillsplitter.adapters;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.mobilebillsplitter.R;
import com.example.mobilebillsplitter.activities.AssignPaymentsActivity;

import java.util.List;

import ServerAPI.objects.Bill;
import ServerAPI.objects.Bills;

public class BillMainAdapter extends ArrayAdapter {

    private List<Bill> bills;
    private Activity context;

    public BillMainAdapter(Activity contextParam, Bills billsParam) {
        super(contextParam, R.layout.row_payment, billsParam.getBills());
        context = contextParam;
        bills = billsParam.getBills();
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View rowView = inflater.inflate(R.layout.row_bill_main, null, true);
        final TextView titleTextView = rowView.findViewById(R.id.rowBillTitleID);
        final TextView dateTextView = rowView.findViewById(R.id.rowBillDateID);
        final TextView personsNumberTextView = rowView.findViewById(R.id.rowPersonsNumberID);

        titleTextView.setText(bills.get(position).getBillTitle());
        dateTextView.setText(bills.get(position).getBillTitle());
        personsNumberTextView.setText(String.valueOf(bills.get(position).getPersonsList().size()));

        rowView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String sourceKey = context.getResources().getString(R.string.SOURCE_CLASS);
                Bundle billBundle = bills.get(position).createBillBundle(context);
                Intent intent = new Intent(context, AssignPaymentsActivity.class);
                intent.putExtras(billBundle);
                intent.putExtra(sourceKey, "BillMainActivity");
                context.startActivity(intent);
            }
        });

        return rowView;

    }

}
