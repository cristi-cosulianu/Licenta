package com.example.mobilebillsplitter.UI;

import android.app.ProgressDialog;
import android.content.Context;

public class LoadingView {

    private Context context;

    private ProgressDialog progressDialog;

    public LoadingView(Context contextParam) {
        context = contextParam;
        initializeProgressDialog();
    }

    private void initializeProgressDialog() {
        progressDialog = new ProgressDialog(context);
        progressDialog.setMessage("Please wait ...");
        progressDialog.setCancelable(false);
    }

    public void show() {
        progressDialog.show();
    }

    public void dismiss() {
        progressDialog.dismiss();
    }
}
