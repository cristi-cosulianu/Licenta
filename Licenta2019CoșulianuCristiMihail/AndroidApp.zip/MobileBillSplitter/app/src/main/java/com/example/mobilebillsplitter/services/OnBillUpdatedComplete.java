package com.example.mobilebillsplitter.services;

import ServerAPI.objects.Bill;

public interface OnBillUpdatedComplete {
    void onBillUpdateComplete(Bill bill);
}
