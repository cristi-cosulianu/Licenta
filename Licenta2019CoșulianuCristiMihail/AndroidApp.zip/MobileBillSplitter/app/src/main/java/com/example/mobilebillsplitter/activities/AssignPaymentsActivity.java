package com.example.mobilebillsplitter.activities;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mobilebillsplitter.UI.LoadingView;
import com.example.mobilebillsplitter.adapters.PaymentsAdapter;
import com.example.mobilebillsplitter.services.GooglePay;
import com.example.mobilebillsplitter.utils.PreferencesController;
import com.example.mobilebillsplitter.R;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.wallet.AutoResolveHelper;
import com.google.android.gms.wallet.IsReadyToPayRequest;
import com.google.android.gms.wallet.PaymentData;
import com.google.android.gms.wallet.PaymentDataRequest;
import com.google.android.gms.wallet.PaymentsClient;
import com.google.android.gms.wallet.Wallet;
import com.google.android.gms.wallet.WalletConstants;

import org.json.JSONException;
import org.json.JSONObject;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import ServerAPI.objects.Bill;
import ServerAPI.objects.Payment;
import ServerAPI.objects.PaymentToPerson;
import ServerAPI.objects.Person;
import ServerAPI.requests.PaymentRequest;

public class AssignPaymentsActivity extends AppCompatActivity {
    private Bill bill;

    private PaymentsAdapter paymentsListAdapter;
    private ListView paymentsListView;

    private List<PaymentToPerson> newPaymentToPersonList;

    private Button mGooglePayButton;
    private Button colorExampleButton;

    private PaymentsClient mPaymentsClient;

    private Float totalSumValue = 0f;

    private TextView totalSumTextView;
    private TextView instructionsTextView;
    private LoadingView loadingView;


    /** A constant integer you define to track a request for payment data activity */
    private static final int LOAD_PAYMENT_DATA_REQUEST_CODE = 42;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assign_payments);

        getIntentData();
        initializePaymentsListView();
        newPaymentToPersonList = new ArrayList<>();
        totalSumTextView = findViewById(R.id.totalSumTextViewID);
        instructionsTextView = findViewById(R.id.paymentsListTitleID);
        colorExampleButton = findViewById(R.id.colorExampleButtonID);
        initializeGooglePayButton();
        initializeLoadingView();

        Intent intent = getIntent();
        String sourceKey = getApplicationContext().getResources().getString(R.string.SOURCE_CLASS);
        String sourceClass = intent.getStringExtra(sourceKey);
        getSupportActionBar().setTitle("Select products page");

        if (sourceClass != null) {
            if ( sourceClass.equals("BillMainActivity")) {
                getSupportActionBar().setTitle("Bill overview");
            }
            if ( sourceClass.equals("PaymentsMainActivity")) {
                getSupportActionBar().setTitle("Payments overview");
            }
            totalSumTextView.setVisibility(View.INVISIBLE);
            mGooglePayButton.setVisibility(View.INVISIBLE);
            instructionsTextView.setText("Your color is: ");
            colorExampleButton.setVisibility(View.VISIBLE);
            colorExampleButton.setBackgroundResource(R.drawable.button_color0);
        }

    }

    private void initializeLoadingView() {
        loadingView = new LoadingView(this);
    }

    private void initializeGooglePayButton() {
        mGooglePayButton = findViewById(R.id.googlePayButtonID);
        if (bill.getInitiator().getId().equals(PreferencesController.getPersonLoggedIn(getApplicationContext()).getId())) {
            mGooglePayButton.setBackgroundResource(R.drawable.navigation_button_yellow);
            mGooglePayButton.setText("Done");
            mGooglePayButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (totalSumValue > 0) {
                        Intent intent = new Intent(AssignPaymentsActivity.this, BillStatusActivity.class);
                        Bundle billBundle = bill.createBillBundle(getApplicationContext());
                        intent.putExtras(billBundle);

                        PaymentRequest paymentRequest = new PaymentRequest(getApplicationContext());
                        updatePaymentToPersonsList();
                        paymentRequest.putPaymentPayer(newPaymentToPersonList, intent, loadingView);
                    } else {
                        Toast.makeText(getApplicationContext(), "Please select some products!", Toast.LENGTH_LONG).show();
                    }
                }
            });
        } else {
            // initialize a Google Pay API client for an environment suitable for testing
            mPaymentsClient =
                    Wallet.getPaymentsClient(
                            this,
                            new Wallet.WalletOptions.Builder()
                                    .setEnvironment(WalletConstants.ENVIRONMENT_TEST)
                                    .build());
            possiblyShowGooglePayButton();
        }
    }

    /**
     * Determine the viewer's ability to pay with a payment method supported by your app and display a
     * Google Pay payment button
     *
     * @see <a
     *     href="https://developers.google.com/android/reference/com/google/android/gms/wallet/PaymentsClient#isReadyToPay(com.google.android.gms.wallet.IsReadyToPayRequest)">PaymentsClient#IsReadyToPay</a>
     */
    private void possiblyShowGooglePayButton() {
        final Optional<JSONObject> isReadyToPayJson = GooglePay.getIsReadyToPayRequest();
        if (!isReadyToPayJson.isPresent()) {
            return;
        }
        IsReadyToPayRequest request = IsReadyToPayRequest.fromJson(isReadyToPayJson.get().toString());
        if (request == null) {
            return;
        }
        Task<Boolean> task = mPaymentsClient.isReadyToPay(request);
        task.addOnCompleteListener(
                new OnCompleteListener<Boolean>() {
                    @Override
                    public void onComplete(@NonNull Task<Boolean> task) {
                        try {
                            boolean result = task.getResult(ApiException.class);
                            if (result) {
                                // show Google as a payment option
                                mGooglePayButton = findViewById(R.id.googlePayButtonID);
                                mGooglePayButton.setOnClickListener(
                                        new View.OnClickListener() {
                                            @Override
                                            public void onClick(View view) {
                                                PaymentRequest paymentRequest = new PaymentRequest(getApplicationContext());
                                                updatePaymentToPersonsList();
                                                paymentRequest.putPaymentPayer(newPaymentToPersonList, AssignPaymentsActivity.this, view);
                                            }
                                        });
                            }
                        } catch (ApiException exception) {
                            // handle developer errors
                        }
                    }
                });
    }

    /**
     * Display the Google Pay payment sheet after interaction with the Google Pay payment button
     *
     * @param view optionally uniquely identify the interactive element prompting for payment
     */
    public void requestPayment(View view) {
        Optional<JSONObject> paymentDataRequestJson = GooglePay.getPaymentDataRequestFor(totalSumValue.toString());
        if (!paymentDataRequestJson.isPresent()) {
            return;
        }
        PaymentDataRequest request =
                PaymentDataRequest.fromJson(paymentDataRequestJson.get().toString());
        if (request != null) {
            AutoResolveHelper.resolveTask(
                    mPaymentsClient.loadPaymentData(request), this, LOAD_PAYMENT_DATA_REQUEST_CODE);
        }
    }

    /**
     * Handle a resolved activity from the Google Pay payment sheet
     *
     * @param requestCode the request code originally supplied to AutoResolveHelper in
     *     requestPayment()
     * @param resultCode the result code returned by the Google Pay API
     * @param data an Intent from the Google Pay API containing payment or error data
     * @see <a href="https://developer.android.com/training/basics/intents/result">Getting a result
     *     from an Activity</a>
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            // value passed in AutoResolveHelper
            case LOAD_PAYMENT_DATA_REQUEST_CODE:
                switch (resultCode) {
                    case Activity.RESULT_OK:
                        PaymentData paymentData = PaymentData.getFromIntent(data);
                        String json = paymentData.toJson();
                        // if using gateway tokenization, pass this token without modification
                        JSONObject paymentMethodData = null;
                        String paymentToken = null;
                        try {
                            paymentMethodData = new JSONObject(json)
                                    .getJSONObject("paymentMethodData");

                            paymentToken = paymentMethodData.getJSONObject("tokenizationData").getString("token");
                            Toast.makeText(getApplicationContext(), "You are done here!", Toast.LENGTH_LONG).show();
                            Intent intent = new Intent(AssignPaymentsActivity.this, MainActivity.class);
                            startActivity(intent);
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(getApplicationContext(), "error", Toast.LENGTH_LONG).show();

                        }

                        break;
                    case Activity.RESULT_CANCELED:
                        Toast.makeText(getApplicationContext(), "canceled", Toast.LENGTH_LONG).show();
                        break;
                    case AutoResolveHelper.RESULT_ERROR:
                        Status status = AutoResolveHelper.getStatusFromIntent(data);
                        Toast.makeText(getApplicationContext(), "" + status, Toast.LENGTH_LONG).show();
                        // Log the status for debugging.
                        // Generally, there is no need to show an error to the user.
                        // The Google Pay payment sheet will present any account errors.
                        break;
                    default:
                        // Do nothing.
                }
                break;
            default:
                // Do nothing.
        }
    }

    private void getIntentData() {
        Bundle bundle = getIntent().getExtras();
        String billKey = getApplicationContext().getResources().getString(R.string.EXTRA_BILL_KEY);
        try {
            bill = bundle.getParcelable(billKey);
        } catch (Exception e) {
            Log.v("EXCEPTION", e.toString());
        }
    }

    private void initializePaymentsListView() {
        PreferencesController.clearPreferences(getApplicationContext());
        PreferencesController.saveSelectedPerson(getApplicationContext(), 0);
        paymentsListAdapter = new PaymentsAdapter(this, bill);
        paymentsListView = findViewById(R.id.assignPersonsListViewID);
        paymentsListView.setAdapter(paymentsListAdapter);
        paymentsListAdapter.notifyDataSetChanged();
    }

    private void updatePaymentToPersonsList() {
        Person selectedPerson = PreferencesController.getPersonLoggedIn(getApplicationContext());

        Integer numberOfPayments = bill.getPaymentsList().size();
        List<Integer> selectedPaymentsLines = PreferencesController.getSelectedPayments(getApplicationContext(), numberOfPayments);
        List<Payment> paymentsList =  bill.getPaymentsList();
        for (Integer index : selectedPaymentsLines) {
            Payment selectedPayment = paymentsList.get(index);
            if (!bill.existPaymentInPaymentsToPerson(selectedPayment)) {
                PaymentToPerson paymentToPerson = new PaymentToPerson(selectedPayment, selectedPerson);
                bill.addPaymentToPerson(paymentToPerson);
                newPaymentToPersonList.add(paymentToPerson);
            }
        }
    }

    public void addToTotalPrice(int currPosition) {
        totalSumValue += bill.getPaymentsList().get(currPosition).getProductPrice();
        updateTotalSumTextView();
    }

    public void subtractFromTotalPrice(int currPosition) {
        totalSumValue -= bill.getPaymentsList().get(currPosition).getProductPrice();
        updateTotalSumTextView();
    }

    private void updateTotalSumTextView() {
        String totalSumText = getResources().getString(R.string.total_sum_text);
        try {
            DecimalFormat decimalFormat = new DecimalFormat("#.##");
            decimalFormat.setRoundingMode(RoundingMode.HALF_UP);
            totalSumText += " " + decimalFormat.format(totalSumValue);
        } catch (Exception e) {
            Log.d("PAYMENTS", "Error at converting from float to string!");
        }
        totalSumTextView.setText(totalSumText);
    }
}
