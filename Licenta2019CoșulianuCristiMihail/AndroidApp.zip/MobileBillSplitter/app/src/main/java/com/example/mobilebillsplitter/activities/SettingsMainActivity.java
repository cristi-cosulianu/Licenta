package com.example.mobilebillsplitter.activities;

import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.view.ViewStub;

import com.example.mobilebillsplitter.UI.LoadingView;
import com.example.mobilebillsplitter.utils.PreferencesController;
import com.example.mobilebillsplitter.R;
import com.example.mobilebillsplitter.modular_layouts.LoggedIn;
import com.example.mobilebillsplitter.modular_layouts.NavigationButtons;
import com.example.mobilebillsplitter.modular_layouts.NotLoggedIn;

public class SettingsMainActivity extends AppCompatActivity {

//    private SwipeRefreshLayout swipeRefreshLayout;

    private ViewStub settingsLogInArea;

    private LoadingView loadingView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings_main);

        getSupportActionBar().setTitle("Settings Activity");


//        swipeRefreshLayout = findViewById(R.id.swipeToRefreshID);
//        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
//            @Override
//            public void onRefresh() {
//                initializeLogInController();
//            }
//        });

        initializeLoadingView();
        initializeLogInController();
        initializeNavigationBar();


    }

    private void initializeLoadingView() {
        loadingView = new LoadingView(this);
    }


    public void initializeLogInController() {
        settingsLogInArea = findViewById(R.id.settingsLogInAreaID);
        if (PreferencesController.isLoggedIn(getApplicationContext())) {
            settingsLogInArea.setLayoutResource(R.layout.user_logged_in);
            settingsLogInArea.inflate();
            LoggedIn loggedInDisplay = new LoggedIn();
            loggedInDisplay.initialize(getApplicationContext(), SettingsMainActivity.this);
        } else {
            settingsLogInArea.setLayoutResource(R.layout.user_not_logged_in);
            settingsLogInArea.inflate();
            NotLoggedIn notLoggedInDisplay = new NotLoggedIn();
            notLoggedInDisplay.initialize(getApplicationContext(), SettingsMainActivity.this);
        }
    }

    private void initializeNavigationBar() {
        NavigationButtons navigationButtons = new NavigationButtons();
        navigationButtons.initialize(getApplicationContext(), SettingsMainActivity.this, loadingView);
    }

}
