package com.example.mobilebillsplitter.services;

import android.app.Activity;
import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import ServerAPI.objects.Bill;
import ServerAPI.requests.BillRequests;

public class BillUpdateTask extends AsyncTask<Bill,Object,Object> { //change Object to required type
    private OnBillUpdatedComplete listener;
    private Activity context;
    private Timer timer;

    public void StopTimer() {
        timer.cancel();
    }

    public BillUpdateTask(Activity activity){
        this.context = activity;
        listener = (OnBillUpdatedComplete) activity;
        timer = new Timer();
    }

    @Override
    protected Object doInBackground(Bill... bills) {
        final List<Bill> billList = Arrays.asList(bills);
        //Set the schedule function
        timer.scheduleAtFixedRate(new TimerTask() {
                          @Override
                          public void run() {
                              BillRequests billRequests = new BillRequests(context);
                              billRequests.getBill(billList.get(0).getBillId(), listener);
                          }
            },
        0, 5000);

        return null;
    }
}
