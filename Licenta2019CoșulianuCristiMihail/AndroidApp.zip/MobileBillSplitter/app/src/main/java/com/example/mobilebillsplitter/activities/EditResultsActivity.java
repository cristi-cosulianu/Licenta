package com.example.mobilebillsplitter.activities;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.example.mobilebillsplitter.UI.LoadingView;
import com.example.mobilebillsplitter.adapters.PaymentsAdapter;
import com.example.mobilebillsplitter.R;
import com.example.mobilebillsplitter.utils.PreferencesController;

import java.util.ArrayList;
import java.util.List;

import ServerAPI.objects.Bill;
import ServerAPI.objects.Payment;
import ServerAPI.objects.Person;
import ServerAPI.requests.BillRequests;

public class EditResultsActivity extends AppCompatActivity {

    private Button doneEditingButton;

    private ListView listView;

    private PaymentsAdapter listAdapter;

    private Bill bill;

    private EditText titleEditText;

    private LoadingView loadingView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_results);

        getSupportActionBar().setTitle("Edit results page");

        getIntentData();

        initializeListView();

        initializeDoneButton();

        initializeLoadingView();

        titleEditText = findViewById(R.id.titleEditTextID);

    }

    private void initializeLoadingView() {
        loadingView = new LoadingView(this);
    }


    private void getIntentData() {
        Bundle bundle = getIntent().getExtras();
        String billKey = getApplicationContext().getResources().getString(R.string.EXTRA_BILL_KEY);
        bill = bundle.getParcelable(billKey);
    }

    private void initializeListView() {
        listAdapter = new PaymentsAdapter(this, bill);
        listView = findViewById(R.id.editPaymentsListViewID);
        listView.setAdapter(listAdapter);
        listAdapter.notifyDataSetChanged();
    }

    private void initializeDoneButton() {
        doneEditingButton = findViewById(R.id.editProductsDoneButtonID);
        doneEditingButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (updateBillObject()) {

                    PreferencesController.saveSelectedPerson(getApplicationContext(), 0);
                    Person initiator = PreferencesController.getPersonLoggedIn(getApplicationContext());
                    bill.setInitiator(initiator);
                    bill.addPerson(initiator);

                    Intent intent = new Intent(EditResultsActivity.this, PersonsActivity.class);
                    BillRequests billPostRequest = new BillRequests(getApplicationContext());
                    billPostRequest.postNewBill(bill, intent, loadingView);
                }

            }
        });
    }

    private boolean updateBillObject() {
        String billTitle = titleEditText.getText().toString();
        if (billTitle.length() > 0) {
            bill.setBillTitle(titleEditText.getText().toString());
            updatePayments();
            return true;
        } else {
            Toast.makeText(getApplicationContext(), "Please insert a title!", Toast.LENGTH_LONG).show();
            return false;
        }
    }

    private void updatePayments() {

        List<Payment> paymentList = bill.getPaymentsList();
        for (int i = 0; i < listView.getChildCount(); i++) {
            View rowView = listView.getChildAt(i);
            EditText productNameView = rowView.findViewById(R.id.productNameID);
            EditText productPriceView = rowView.findViewById(R.id.productPriceID);
            String productName = productNameView.getText().toString();
            Float productPrice = Float.valueOf(productPriceView.getText().toString());
            if (!productName.equals(paymentList.get(i).getProductName()) || !productPrice.equals(paymentList.get(i).getProductPrice())) {
                Payment newPayment = new Payment(productName, productPrice);
                paymentList.set(i, newPayment);
            }
        }
    }

    private void initializeBills() {
        // Request the bills where this person is initiator.

        Person person1 = new Person("id", "Eugen");
        Person person2 = new Person("id", "Costel");
        Payment payment1 = new Payment("Costite", (float) 44.0);
        Payment payment2 = new Payment("Burger", (float) 27.5);
        Payment payment3 = new Payment("Cartofi prajiti", (float) 8.5);
        Payment payment4 = new Payment("Supa de legume", (float) 8.0);
        List<Person> personList = new ArrayList<>();
        personList.add(person1);

        List<Payment> paymentList = new ArrayList<>();
        paymentList.add(payment1);
        paymentList.add(payment2);
        paymentList.add(payment3);
        paymentList.add(payment4);

        bill = new Bill(paymentList , personList, "Mammamia");
        bill.setBillId("5ce19b85da69af4e2ca3393a");

        Person initiator = PreferencesController.getPersonLoggedIn(getApplicationContext());
        bill.setInitiator(initiator);

    }
}
