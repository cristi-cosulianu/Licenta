package com.example.mobilebillsplitter.activities;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.mobilebillsplitter.R;
import com.example.mobilebillsplitter.UI.LoadingView;

import ServerAPI.requests.BillRequests;

public class JoinBillActivity extends AppCompatActivity {

    private Button joinButton;

    private EditText billIdEditText;

    private LoadingView loadingView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_join_bill);

        getSupportActionBar().setTitle("Join bill page");

        billIdEditText = findViewById(R.id.billCodeEditTextID);

        loadingView = new LoadingView(this);

        joinButton = findViewById(R.id.joinBillButtonID);
        joinButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String billId = billIdEditText.getText().toString();
                if (billId.length() == 24) {
                    Intent intent = new Intent(JoinBillActivity.this, AssignPaymentsActivity.class);
                    BillRequests billRequests = new BillRequests(getApplicationContext());
                    billRequests.getBill(billId, intent, loadingView);
                } else {
                    Toast.makeText(getApplicationContext(), "Invalid id!", Toast.LENGTH_LONG).show();
                }
            }
        });



    }
}
