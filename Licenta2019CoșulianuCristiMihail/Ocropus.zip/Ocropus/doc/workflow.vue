<!-- Tufts VUE 3.3.0 concept-map (workflow.vue) 2017-02-14 -->
<!-- Tufts VUE: http://vue.tufts.edu/ -->
<!-- Do Not Remove: VUE mapping @version(1.1) jar:file:/C:/Program%20Files%20(x86)/VUE/VUE.jar!/tufts/vue/resources/lw_mapping_1_1.xml -->
<!-- Do Not Remove: Saved date Tue Feb 14 23:17:59 CET 2017 by zumstein on platform Windows 8 6.2 in JVM 1.7.0_21-b11 -->
<!-- Do Not Remove: Saving version @(#)VUE: built October 8 2015 at 1658 by tomadm on Linux 2.6.32-504.23.4.el6.x86_64 i386 JVM 1.7.0_21-b11(bits=32) -->
<?xml version="1.0" encoding="US-ASCII"?>
<LW-MAP xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xsi:noNamespaceSchemaLocation="none" ID="0" label="workflow.vue"
    created="1486884820490" x="0.0" y="0.0" width="918.0" height="585.5"
    strokeWidth="0.0" autoSized="false">
    <resource referenceCreated="1487110679127" size="31065"
        spec="C:\Users\zumstein\Coding\ocropy\doc\workflow.vue" type="1" xsi:type="URLResource">
        <title>workflow.vue</title>
        <property key="File" value="C:\Users\zumstein\Coding\ocropy\doc\workflow.vue"/>
    </resource>
    <fillColor>#FFFFFF</fillColor>
    <strokeColor>#404040</strokeColor>
    <textColor>#000000</textColor>
    <font>SansSerif-plain-14</font>
    <URIString>http://vue.tufts.edu/rdf/resource/318fb784c0a863010132f845df22b96d</URIString>
    <child ID="6" label="ocropus-dewarp" layerID="1"
        created="1486884834412" x="205.86902" y="146.77135"
        width="131.0" height="53.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#FEFD8C</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb784c0a863010132f845ce9098a7</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="8" label="ocropus-errs&#xa;ocropus-econf" layerID="1"
        created="1486884899981" x="761.08716" y="150.4456" width="131.0"
        height="53.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <resource referenceCreated="0"
            spec="https://github.com/tmbdev/ocropy/wiki/Compute-errors-and-confusions"
            type="2" xsi:type="URLResource">
            <property key="URL" value="https://github.com/tmbdev/ocropy/wiki/Compute-errors-and-confusions"/>
        </resource>
        <fillColor>#FCDBD9</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb784c0a863010132f8454bf13a67</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="9" label="ocropus-gpageseg" layerID="1"
        created="1486884913903" x="284.5" y="49.5" width="144.0"
        height="53.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <resource referenceCreated="0"
            spec="https://github.com/tmbdev/ocropy/wiki/Page-Segmentation"
            type="2" xsi:type="URLResource">
            <property key="URL" value="https://github.com/tmbdev/ocropy/wiki/Page-Segmentation"/>
        </resource>
        <fillColor>#FDE888</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb784c0a863010132f84518cb4f19</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="10" label="ocropus-gtedit html" layerID="1"
        created="1486884925867" x="525.08716" y="144.4456" width="145.0"
        height="53.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <resource referenceCreated="0"
            spec="https://github.com/tmbdev/ocropy/wiki/Working-with-Ground-Truth"
            type="2" xsi:type="URLResource">
            <property key="URL" value="https://github.com/tmbdev/ocropy/wiki/Working-with-Ground-Truth"/>
        </resource>
        <fillColor>#BDE5F2</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb784c0a863010132f84589f5463e</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="11" label="ocropus-hocr" layerID="1"
        created="1486884938433" x="533.08716" y="-53.554398"
        width="131.0" height="53.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#C1F780</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb784c0a863010132f84553ad18d6</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="12" label="ocropus-linegen" layerID="1"
        created="1486884948679" x="758.66315" y="339.4023" width="131.0"
        height="53.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#F4E5FF</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb793c0a863010132f8458236689b</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="15" label="ocropus-nlbin" layerID="1"
        created="1486884969947" x="58.5" y="46.5" width="131.0"
        height="53.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb793c0a863010132f845f7af52fb</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="16" label="ocropus-rpred&#xa;ocropus-lpred" layerID="1"
        created="1486885055534" x="532.08716" y="49.445602"
        width="131.0" height="53.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb793c0a863010132f84585150a4b</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="17" label="ocropus-rtrain&#xa;ocropus-ltraing"
        layerID="1" created="1486885066204" x="759.66315" y="254.40233"
        width="131.0" height="53.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#C6E8FF</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb793c0a863010132f845c1b60a3d</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="18" label="ocropus-visualize-results" layerID="1"
        created="1486885090214" x="695.08716" y="-54.554398"
        width="149.0" height="53.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#C1F780</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb793c0a863010132f845d95ffe69</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="20" label="0001.bin.png" layerID="1"
        created="1486885451634" x="189.0" y="67.45807" width="96.0"
        height="14.0" strokeWidth="1.0" autoSized="false"
        controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb793c0a863010132f8454b0adb7a</URIString>
        <point1 x="189.5" y="73.84516"/>
        <point2 x="284.5" y="75.07097"/>
        <ID1 xsi:type="node">15</ID1>
        <ID2 xsi:type="node">9</ID2>
    </child>
    <child ID="22" label="0001/*.bin.png" layerID="1"
        created="1486885739787" x="428.0" y="68.97206" width="104.58716"
        height="14.0" strokeWidth="1.0" autoSized="false"
        controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb793c0a863010132f8454567d994</URIString>
        <point1 x="428.5" y="75.98375"/>
        <point2 x="532.08716" y="75.96038"/>
        <ID1 xsi:type="node">9</ID1>
        <ID2 xsi:type="node">16</ID2>
    </child>
    <child ID="23" label="0001/*.txt" layerID="1"
        created="1486886032784" x="575.08716" y="-1.0585938"
        width="46.0" height="51.003906" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb793c0a863010132f8458a93431e</URIString>
        <point1 x="597.8444" y="49.445312"/>
        <point2 x="598.3299" y="-0.55859375"/>
        <ID1 xsi:type="node">16</ID1>
        <ID2 xsi:type="node">11</ID2>
    </child>
    <child ID="24" label="0001.pseg.png" layerID="1"
        created="1486886049753" x="418.17072" y="-2.1046295"
        width="121.1319" height="52.1391" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb793c0a863010132f8459f3758b9</URIString>
        <point1 x="418.67072" y="49.53447"/>
        <point2 x="538.8026" y="-1.6046295"/>
        <ID1 xsi:type="node">9</ID1>
        <ID2 xsi:type="node">11</ID2>
    </child>
    <child ID="26" layerID="1" created="1486886442180" x="640.91406"
        y="-2.0544128" width="85.34625" height="52.00003"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb793c0a863010132f845ef3fb338</URIString>
        <point1 x="641.414" y="49.445618"/>
        <point2 x="725.76025" y="-1.5544128"/>
        <ID1 xsi:type="node">16</ID1>
        <ID2 xsi:type="node">18</ID2>
    </child>
    <child ID="27" label="ocropus-gtedit extract" layerID="1"
        created="1486886687343" x="519.0328" y="253.77193" width="156.0"
        height="53.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <resource referenceCreated="0"
            spec="https://github.com/tmbdev/ocropy/wiki/Working-with-Ground-Truth"
            type="2" xsi:type="URLResource">
            <property key="URL" value="https://github.com/tmbdev/ocropy/wiki/Working-with-Ground-Truth"/>
        </resource>
        <fillColor>#BDE5F2</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb793c0a863010132f8457ba86140</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="30" label="0001/*.bin.png" layerID="1"
        created="1486886946404" x="421.49664" y="101.29407"
        width="110.92444" height="44.29074" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb793c0a863010132f845fb9ebbd2</URIString>
        <point1 x="421.99664" y="101.79407"/>
        <point2 x="531.9211" y="145.08481"/>
        <ID1 xsi:type="node">9</ID1>
        <ID2 xsi:type="node">10</ID2>
    </child>
    <child ID="31" label="0001/*.txt" layerID="1"
        created="1486886947889" x="574.58716" y="101.9456" width="46.0"
        height="43.0" strokeWidth="1.0" autoSized="false"
        controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb793c0a863010132f8455ca38564</URIString>
        <point1 x="597.58716" y="102.4456"/>
        <point2 x="597.58716" y="144.4456"/>
        <ID1 xsi:type="node">16</ID1>
        <ID2 xsi:type="node">10</ID2>
    </child>
    <child ID="32" label="0001/*.txt" layerID="1"
        created="1486887082706" x="655.7319" y="101.310745"
        width="112.71057" height="50.269714" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb793c0a863010132f845de2fbf92</URIString>
        <point1 x="656.2319" y="101.810745"/>
        <point2 x="767.94244" y="151.08046"/>
        <ID1 xsi:type="node">16</ID1>
        <ID2 xsi:type="node">8</ID2>
    </child>
    <child ID="33" label="0001/*.gt.txt" layerID="1"
        created="1486887084862" x="655.4064" y="202.47543"
        width="113.85181" height="51.79648" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb793c0a863010132f845741765fa</URIString>
        <point1 x="655.9064" y="253.77191"/>
        <point2 x="768.7582" y="202.97543"/>
        <ID1 xsi:type="node">27</ID1>
        <ID2 xsi:type="node">8</ID2>
    </child>
    <child ID="34" label="correction.html" layerID="1"
        created="1486887088550" x="561.30994" y="196.9375" width="72.0"
        height="57.335938" strokeWidth="1.0" autoSized="false"
        controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb793c0a863010132f8457996913f</URIString>
        <point1 x="597.4528" y="197.4375"/>
        <point2 x="597.1671" y="253.77344"/>
        <ID1 xsi:type="node">10</ID1>
        <ID2 xsi:type="node">27</ID2>
    </child>
    <child ID="39" label="0001/*.gt.txt" layerID="1"
        created="1486887677550" x="674.5328" y="273.60443"
        width="85.63037" height="14.0" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb793c0a863010132f845929ecbd0</URIString>
        <point1 x="675.0328" y="280.4875"/>
        <point2 x="759.66315" y="280.72134"/>
        <ID1 xsi:type="node">27</ID1>
        <ID2 xsi:type="node">17</ID2>
    </child>
    <child ID="40" label="0001/*.bin.png" layerID="1"
        created="1486887705144" x="357.6407" y="102.0" width="407.89264"
        height="253.98706" strokeWidth="1.0" autoSized="false"
        controlCount="1" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb793c0a863010132f845ab5b61d2</URIString>
        <point1 x="358.1407" y="102.5"/>
        <point2 x="765.0333" y="306.11932"/>
        <ID1 xsi:type="node">9</ID1>
        <ID2 xsi:type="node">17</ID2>
        <ctrlPoint0 x="380.7257" y="467.2886" xsi:type="point"/>
    </child>
    <child ID="41" layerID="1" created="1486887716926" x="294.06155"
        y="102.0" width="39.74591" height="45.271362" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb793c0a863010132f845e4a6785d</URIString>
        <point1 x="333.30746" y="102.5"/>
        <point2 x="294.56155" y="146.77136"/>
        <ID1 xsi:type="node">9</ID1>
        <ID2 xsi:type="node">6</ID2>
    </child>
    <child ID="43" layerID="1" created="1486887720692" x="823.975"
        y="306.89844" width="1.3765259" height="33.0" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb793c0a863010132f845c325502b</URIString>
        <point1 x="824.4749" y="339.39844"/>
        <point2 x="824.85144" y="307.39844"/>
        <ID1 xsi:type="node">12</ID1>
        <ID2 xsi:type="node">17</ID2>
    </child>
    <child ID="45" label="input image" layerID="1"
        created="1486888705251" x="85.0" y="-3.0" width="76.0"
        height="23.0" strokeWidth="0.0" autoSized="true" xsi:type="node">
        <fillColor>#00000000</fillColor>
        <strokeColor>#00000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb793c0a863010132f8459601c0e0</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="46" layerID="1" created="1486888709720" x="122.67828"
        y="19.5" width="1.4108505" height="27.5" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb793c0a863010132f845896bcbe5</URIString>
        <point1 x="123.17829" y="20.0"/>
        <point2 x="123.58914" y="46.5"/>
        <ID1 xsi:type="node">45</ID1>
        <ID2 xsi:type="node">15</ID2>
    </child>
    <child ID="47" label="input font" layerID="1"
        created="1486888851751" x="759.06555" y="420.66318" width="61.0"
        height="23.0" strokeWidth="0.0" autoSized="true" xsi:type="node">
        <fillColor>#00000000</fillColor>
        <strokeColor>#00000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb793c0a863010132f8452961800d</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="48" label="input text" layerID="1"
        created="1486888865122" x="844.2392" y="420.4023" width="59.0"
        height="23.0" strokeWidth="0.0" autoSized="true" xsi:type="node">
        <fillColor>#00000000</fillColor>
        <strokeColor>#00000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb7a3c0a863010132f845ea9c40dc</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="49" layerID="1" created="1486888891764" x="795.0702"
        y="391.90234" width="15.756165" height="29.260864"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb7a3c0a863010132f8451d8b60d8</URIString>
        <point1 x="795.5702" y="420.6632"/>
        <point2 x="810.32635" y="392.40234"/>
        <ID1 xsi:type="node">47</ID1>
        <ID2 xsi:type="node">12</ID2>
    </child>
    <child ID="50" layerID="1" created="1486888893842" x="843.5687"
        y="391.90234" width="22.032288" height="29.0" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb7a3c0a863010132f8458b475e35</URIString>
        <point1 x="865.10095" y="420.40234"/>
        <point2 x="844.06866" y="392.40234"/>
        <ID1 xsi:type="node">48</ID1>
        <ID2 xsi:type="node">12</ID2>
    </child>
    <child ID="51" label="hocr-pdf" layerID="1" created="1486889016225"
        x="535.08716" y="-149.5544" width="131.0" height="53.0"
        strokeWidth="1.0" strokeStyle="2" autoSized="false" xsi:type="node">
        <resource referenceCreated="0"
            spec="https://github.com/tmbdev/hocr-tools#hocr-pdf"
            type="2" xsi:type="URLResource">
            <property key="URL" value="https://github.com/tmbdev/hocr-tools#hocr-pdf"/>
        </resource>
        <fillColor>#8AEE95</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb7a3c0a863010132f8454b5b7edb</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="52" label="0001.hocr" layerID="1" created="1486889112711"
        x="575.08716" y="-97.05469" width="49.0" height="44.0"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb7a3c0a863010132f845922f425a</URIString>
        <point1 x="599.1392" y="-53.554688"/>
        <point2 x="600.0351" y="-96.55469"/>
        <ID1 xsi:type="node">11</ID1>
        <ID2 xsi:type="node">51</ID2>
    </child>
    <child ID="53" label="0001.bin.png" layerID="1"
        created="1486889120930" x="184.07318" y="-98.636314"
        width="356.4408" height="147.21823" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb7a3c0a863010132f8453462164d</URIString>
        <point1 x="184.57318" y="48.081917"/>
        <point2 x="540.014" y="-98.13632"/>
        <ID1 xsi:type="node">15</ID1>
        <ID2 xsi:type="node">51</ID2>
    </child>
    <child ID="54" label="recognized text" layerID="1"
        created="1486889193686" x="750.08716" y="65.4456" width="92.0"
        height="23.0" strokeWidth="0.0" autoSized="true" xsi:type="node">
        <fillColor>#00000000</fillColor>
        <strokeColor>#00000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb7a3c0a863010132f84584bbd69e</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="55" label="pdf (image + overlayed text)" layerID="1"
        created="1486889220342" x="703.58716" y="-133.5544"
        width="160.0" height="23.0" strokeWidth="0.0" autoSized="true" xsi:type="node">
        <fillColor>#00000000</fillColor>
        <strokeColor>#00000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb7a3c0a863010132f845b505c773</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="56" label="error rate&#xa;confusions" layerID="1"
        created="1486889310057" x="913.58716" y="153.4456" width="72.0"
        height="38.0" strokeWidth="0.0" autoSized="true" xsi:type="node">
        <fillColor>#00000000</fillColor>
        <strokeColor>#00000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb7a3c0a863010132f845bff8331a</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="57" label="model" layerID="1" created="1486889330840"
        x="931.16315" y="269.4023" width="46.0" height="23.0"
        strokeWidth="0.0" autoSized="true" xsi:type="node">
        <fillColor>#00000000</fillColor>
        <strokeColor>#00000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb7a3c0a863010132f84589beccc1</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="58" layerID="1" created="1486889365293" x="665.58716"
        y="-123.19647" width="38.5" height="1.2049179" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb7a3c0a863010132f8450cc25a8c</URIString>
        <point1 x="666.08716" y="-122.69647"/>
        <point2 x="703.58716" y="-122.491554"/>
        <ID1 xsi:type="node">51</ID1>
        <ID2 xsi:type="node">55</ID2>
    </child>
    <child ID="59" layerID="1" created="1486889369559" x="662.58716"
        y="75.77557" width="88.0" height="1.4382858" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb7a3c0a863010132f845037e6bc5</URIString>
        <point1 x="663.08716" y="76.27558"/>
        <point2 x="750.08716" y="76.71387"/>
        <ID1 xsi:type="node">16</ID1>
        <ID2 xsi:type="node">54</ID2>
    </child>
    <child ID="60" layerID="1" created="1486889371231" x="891.58716"
        y="173.26268" width="22.5" height="1.7865906" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb7a3c0a863010132f84511938fb9</URIString>
        <point1 x="892.08716" y="174.54927"/>
        <point2 x="913.58716" y="173.76268"/>
        <ID1 xsi:type="node">8</ID1>
        <ID2 xsi:type="node">56</ID2>
    </child>
    <child ID="61" layerID="1" created="1486889373122" x="890.16315"
        y="280.4023" width="41.5" height="1.0" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/318fb7a3c0a863010132f845081b085d</URIString>
        <point1 x="890.66315" y="280.9023"/>
        <point2 x="931.16315" y="280.9023"/>
        <ID1 xsi:type="node">17</ID1>
        <ID2 xsi:type="node">57</ID2>
    </child>
    <layer ID="1" label="Layer 1" created="1486884820490" x="0.0"
        y="0.0" width="1.4E-45" height="1.4E-45" strokeWidth="0.0" autoSized="false">
        <URIString>http://vue.tufts.edu/rdf/resource/318fb7a3c0a863010132f845906700ea</URIString>
    </layer>
    <userZoom>1.4602903501280957</userZoom>
    <userOrigin x="-187.02989" y="-235.62297"/>
    <presentationBackground>#202020</presentationBackground>
    <PathwayList currentPathway="0" revealerIndex="-1">
        <pathway ID="0" label="Unbenannter Pfad" created="1486884820490"
            x="0.0" y="0.0" width="1.4E-45" height="1.4E-45"
            strokeWidth="0.0" autoSized="false" currentIndex="0" open="true">
            <strokeColor>#B3993333</strokeColor>
            <textColor>#000000</textColor>
            <font>SansSerif-plain-14</font>
            <URIString>http://vue.tufts.edu/rdf/resource/318fb7a3c0a863010132f8456e29f5c4</URIString>
            <masterSlide ID="2" created="1486884820506" x="0.0" y="0.0"
                width="800.0" height="600.0" locked="true"
                strokeWidth="0.0" autoSized="false">
                <fillColor>#000000</fillColor>
                <strokeColor>#404040</strokeColor>
                <textColor>#000000</textColor>
                <font>SansSerif-plain-14</font>
                <URIString>http://vue.tufts.edu/rdf/resource/318fb7a3c0a863010132f845cf3434ea</URIString>
                <titleStyle ID="3" label="Header"
                    created="1486884820693" x="335.5" y="172.5"
                    width="129.0" height="55.0" strokeWidth="0.0"
                    autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#FFFFFF</textColor>
                    <font>Gill Sans-plain-36</font>
                    <URIString>http://vue.tufts.edu/rdf/resource/318fb7a3c0a863010132f845321d1e19</URIString>
                    <shape xsi:type="rectangle"/>
                </titleStyle>
                <textStyle ID="4" label="Slide Text"
                    created="1486884820693" x="346.5" y="281.5"
                    width="107.0" height="37.0" strokeWidth="0.0"
                    autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#FFFFFF</textColor>
                    <font>Gill Sans-plain-22</font>
                    <URIString>http://vue.tufts.edu/rdf/resource/318fb7a3c0a863010132f845f4e853e1</URIString>
                    <shape xsi:type="rectangle"/>
                </textStyle>
                <linkStyle ID="5" label="Links" created="1486884820693"
                    x="373.5" y="384.0" width="53.0" height="32.0"
                    strokeWidth="0.0" autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#B3BFE3</textColor>
                    <font>Gill Sans-plain-18</font>
                    <URIString>http://vue.tufts.edu/rdf/resource/318fb7a3c0a863010132f845064dfc81</URIString>
                    <shape xsi:type="rectangle"/>
                </linkStyle>
            </masterSlide>
        </pathway>
    </PathwayList>
    <date>2017-02-12</date>
    <modelVersion>6</modelVersion>
    <saveLocation>C:\Users\zumstein\Coding\ocropy\doc</saveLocation>
    <saveFile>C:\Users\zumstein\Coding\ocropy\doc\workflow.vue</saveFile>
</LW-MAP>
