You can find a list of available pre-trained models for ocropy here:

https://github.com/tmbdev/ocropy/wiki/Models

Copy the models into this directory to use them.
