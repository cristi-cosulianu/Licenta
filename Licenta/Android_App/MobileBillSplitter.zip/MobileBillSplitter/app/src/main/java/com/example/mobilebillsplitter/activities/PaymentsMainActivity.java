package com.example.mobilebillsplitter.activities;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import com.example.mobilebillsplitter.R;
import com.example.mobilebillsplitter.adapters.BillMainAdapter;
import com.example.mobilebillsplitter.adapters.PaymentsMainAdapter;
import com.example.mobilebillsplitter.modular_layouts.NavigationButtons;

import java.util.ArrayList;
import java.util.List;

import ServerAPI.objects.Bill;
import ServerAPI.objects.Payment;
import ServerAPI.objects.Person;

public class PaymentsMainActivity extends AppCompatActivity {

    private PaymentsMainAdapter paymentsAdapter;
    private ListView paymentsView;

    private List<Bill> bills;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payments_main);

        getSupportActionBar().setTitle("Payments Activity");

        initializeBillsListView();

        NavigationButtons navigationButtons = new NavigationButtons();
        navigationButtons.initialize(getApplicationContext(), PaymentsMainActivity.this);
    }

    private void initializeBillsListView() {
        initializeBills();

        paymentsAdapter = new PaymentsMainAdapter(this, bills);
        paymentsView = findViewById(R.id.paymentsMainListViewID);
        paymentsView.setAdapter(paymentsAdapter);
        paymentsAdapter.notifyDataSetChanged();
    }

    private void initializeBills() {
        // Request the bills where this person is initiator.

        Person person1 = new Person("id", "Eugen");
        Person person2 = new Person("id", "Costel");
        Payment payment1 = new Payment("Costite", (float) 44.0);
        Payment payment2 = new Payment("Burger", (float) 27.5);
        Payment payment3 = new Payment("Cartofi prajiti", (float) 8.5);
        Payment payment4 = new Payment("Supa de legume", (float) 8.0);
        List<Person> personList = new ArrayList<>();
        personList.add(person1);
        personList.add(person2);
        List<Payment> paymentList = new ArrayList<>();
        paymentList.add(payment1);
        paymentList.add(payment2);
        paymentList.add(payment3);
        paymentList.add(payment4);

        bills = new ArrayList<>();
        Bill bill1 = new Bill(paymentList , personList, "Mammamia");
        Bill bill2 = new Bill(paymentList , personList,"Take and eat");
        Bill bill3 = new Bill(paymentList , personList,"Baza");
        Bill bill4 = new Bill(paymentList , personList,"Curtea berarilor");
        bill1.setInitiatorName("Cristi");
        bill2.setInitiatorName("Vasile");
        bill3.setInitiatorName("Adrian");
        bill4.setInitiatorName("Dragos");


        bills.add(bill1); bills.add(bill2); bills.add(bill3); bills.add(bill4);
    }
}
