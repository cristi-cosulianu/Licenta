package ServerAPI.responses;

public class FoundResponse {
    private boolean searchResult;

    public boolean getSearchResult() {
        return searchResult;
    }

    public void setSearchResult(boolean searchResultParam) {
         searchResult = searchResultParam;
    }

    @Override
    public String toString() {
        return String.valueOf(searchResult);
    }
}
