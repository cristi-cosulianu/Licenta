package com.example.mobilebillsplitter.adapters;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.mobilebillsplitter.R;
import com.example.mobilebillsplitter.activities.AssignPaymentsActivity;

import java.util.List;

import ServerAPI.objects.Bill;

public class PaymentsMainAdapter extends ArrayAdapter {

    private Activity context;
    private List<Bill> bills;

    public PaymentsMainAdapter(Activity contextParam, List<Bill> billParam) {
        super(contextParam, R.layout.row_payment_main, billParam);
        context = contextParam;
        bills = billParam;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.row_payment_main, null, true);
        final TextView titleTextView = rowView.findViewById(R.id.rowPaymentTitleID);
        final TextView dateTextView = rowView.findViewById(R.id.rowPaymentDateID);
        final TextView personsNumberTextView = rowView.findViewById(R.id.rowBillInitiatorID);

        titleTextView.setText(bills.get(position).getBillTitle());
        dateTextView.setText(bills.get(position).getBillTitle());
        personsNumberTextView.setText(bills.get(position).getInitiatorId());

        rowView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, AssignPaymentsActivity.class);
                Bundle billBundle = bills.get(position).createBillBundle(context);
                intent.putExtras(billBundle);
                context.startActivity(intent);
            }
        });


        return rowView;
    }
}
