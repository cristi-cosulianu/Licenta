package com.example.mobilebillsplitter.interfaces;

import java.util.List;

import ServerAPI.objects.Person;

public interface OnDataReceive {

    public void OnDataReceive(List<Person> personList);
}
