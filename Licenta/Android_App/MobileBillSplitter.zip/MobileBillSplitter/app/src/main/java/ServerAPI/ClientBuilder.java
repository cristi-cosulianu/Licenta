package ServerAPI;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ClientBuilder {

    private static Retrofit retrofit;
    private static final String BASE_URL = "https://48b6ce02.ngrok.io/";

    public static MBSServerApi createService() {

        if (retrofit == null) {
            OkHttpClient okHttpClient = new OkHttpClient.Builder()
                    .build();
            retrofit = new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .client(okHttpClient)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
            return retrofit.create(MBSServerApi.class);
        } else {
            return retrofit.create(MBSServerApi.class);
        }

    }

}