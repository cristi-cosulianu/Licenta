package com.example.mobilebillsplitter.services;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Point;
import android.graphics.Rect;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.ml.vision.FirebaseVision;
import com.google.firebase.ml.vision.common.FirebaseVisionImage;
import com.google.firebase.ml.vision.text.FirebaseVisionCloudTextRecognizerOptions;
import com.google.firebase.ml.vision.text.FirebaseVisionText;
import com.google.firebase.ml.vision.text.FirebaseVisionTextRecognizer;

import java.security.cert.PolicyNode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

import ServerAPI.objects.Bill;
import ServerAPI.objects.Payment;

public class GoogleVision {

    private Context context;
    private Activity initialActivity;
    private Class destinationClass;

    public GoogleVision(Context context, Activity initialActivityParam, Class destinationClassParam) {
        this.context = context;
        initialActivity = initialActivityParam;
        destinationClass = destinationClassParam;
    }

    public void runTextRecognition(Bitmap imageBitmap) {
        FirebaseVisionImage image = FirebaseVisionImage.fromBitmap(imageBitmap);
        FirebaseVisionCloudTextRecognizerOptions options = new FirebaseVisionCloudTextRecognizerOptions.Builder()
                .setLanguageHints(Arrays.asList("ro", "hi"))
                .setLanguageHints(Arrays.asList("en", "hi"))
                .build();
        FirebaseVisionTextRecognizer detector = FirebaseVision.getInstance()
          .getCloudTextRecognizer(options);
//        FirebaseVisionTextRecognizer detector = FirebaseVision.getInstance().getOnDeviceTextRecognizer();
        detector.processImage(image)
                .addOnSuccessListener(
                        new OnSuccessListener<FirebaseVisionText>() {
                            @Override
                            public void onSuccess(FirebaseVisionText texts) {
                                processTextRecognitionResult(texts);
                                Toast.makeText(context, "RECOGNITION_SUCCESS", Toast.LENGTH_LONG).show();
                            }
                        })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        e.printStackTrace();
                        Toast.makeText(context, "RECOGNITION_FAILURE", Toast.LENGTH_LONG).show();
                    }
                });
    }

    private void processTextRecognitionResult(FirebaseVisionText texts) {
        List<FirebaseVisionText.TextBlock> blocks = texts.getTextBlocks();
        if (blocks.size() == 0) {
            Toast.makeText(context, "NO_TEXT_FOUND", Toast.LENGTH_LONG).show();
            return;
        }

        List<FirebaseVisionText.Line> allLines = new ArrayList<>();
        List<Boolean> isPriceList = new ArrayList<>();
        for (int i = 0; i < blocks.size(); i++) {
            List<FirebaseVisionText.Line> lines = blocks.get(i).getLines();
            allLines.addAll(lines);
            isPriceList.add(Boolean.FALSE);
        }

        Comparator<FirebaseVisionText.Line> lineComparator = new Comparator<FirebaseVisionText.Line>() {
            @Override
            public int compare(FirebaseVisionText.Line o1, FirebaseVisionText.Line o2) {
                Rect box1 = o1.getBoundingBox();
                Rect box2 = o2.getBoundingBox();
                Point point1 = new Point(box1.left, box1.top);
                Point point2 = new Point(box2.left, box2.top);

                if (point1.y == point2.y) {
                    if (point1.x == point2.x) {
                        return 0;
                    } else if (point1.x < point2.x) {
                        return -1;
                    } else {
                        return 1;
                    }
                }
                if (point1.y < point2.y) {
                    return -1;
                }
                return 1;
            }
        };

        allLines.sort(lineComparator);
        List<String> productNameList = new ArrayList<>();
        List<String> productUnsurePriceList = new ArrayList<>();
        List<String> productSurePriceList = new ArrayList<>();
        for (FirebaseVisionText.Line line : allLines) {
            Log.v("PERCENTAGE", "" + line.getText() + " - " + digitsPercentage(line.getText()));
            String lineText = line.getText();
            if (isPrice(lineText) && digitsPercentage(lineText) >= 0.5) {
                productSurePriceList.add(lineText);
            } else if (isPrice(lineText) && digitsPercentage(lineText) >= 0.3) {
                productUnsurePriceList.add(lineText);
            } else {
                productNameList.add(lineText);
            }
        }

        List<String> productPriceList;
        if (productSurePriceList.size() >= productUnsurePriceList.size()) {
            productPriceList = productSurePriceList;
        } else {
            productPriceList = productUnsurePriceList;
        }

        List<Float> prices = extractFloatValues(productPriceList);

        List<Payment> listOfPayments = new ArrayList<>();
        for (int i = 0; i < prices.size(); i++) {
            Payment payment = new Payment();
            if (i < productNameList.size()) {
                payment.setProductName(productNameList.get(i));
            }
            payment.setProductPrice(prices.get(i));

            listOfPayments.add(payment);
            Log.v("PAYMENT", listOfPayments.get(i).getProductName() + "  " + listOfPayments.get(i).getProductPrice());
            prepareNextActivity(listOfPayments);
        }
    }

    private boolean isPrice(String string) {
        if (digitsPercentage(string) > 0.26) {
            return true;
        } else {
            return false;
        }
    }

    private Float digitsPercentage(String string) {
        Float digits = 0f;
        for (int i = 0; i < string.length(); i++) {
            char character = string.charAt(i);
            if ("0123456789".contains(String.valueOf(character))) {
                digits += 1;
            }
//            else if (!".,;!?/*-+".contains(String.valueOf(character))) {
//                letters += 1;
//            }
        }
        return digits / string.length();
    }

    private List<Float> extractFloatValues(List<String> priceStringList) {
        List<Float> priceValues = new ArrayList<>();
        for (String priceString : priceStringList) {
            Float value = extractFloatValue(priceString);
            if (value != null) {
                priceValues.add(value);
            }
        }
        return priceValues;
    }

    private Float extractFloatValue(String priceString) {
        priceString = priceString.replace(",", ".");
        String[] strings = priceString.split(" ");
        for (int i = strings.length - 1; i >= 0; i--) {
            try {
                return Float.valueOf(strings[i]);
            } catch (Exception e) {
                Log.v("Error", e.getStackTrace().toString());
            }
        }
        return null;
    }

    private void prepareNextActivity(List<Payment> paymentList) {
        Log.v("Upload", "success: " + paymentList);

        Bill bill = new Bill();
        for (Payment payment : paymentList) {
            bill.addPayment(payment);
        }

        Intent intent = new Intent(initialActivity, destinationClass);
        Bundle billBundle = bill.createBillBundle(context);
        intent.putExtras(billBundle);

        context.startActivity(intent);
    }
}
