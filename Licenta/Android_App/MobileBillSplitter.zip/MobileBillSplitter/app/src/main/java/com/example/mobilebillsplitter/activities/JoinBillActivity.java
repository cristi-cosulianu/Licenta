package com.example.mobilebillsplitter.activities;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.example.mobilebillsplitter.R;

public class JoinBillActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_join_bill);

        getSupportActionBar().setTitle("Join bill page");

    }
}
