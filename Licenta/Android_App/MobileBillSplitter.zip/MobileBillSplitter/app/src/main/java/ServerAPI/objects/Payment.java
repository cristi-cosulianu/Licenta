package ServerAPI.objects;

import android.os.Parcel;
import android.os.Parcelable;

public class Payment implements Parcelable {
    private String paymentId;
    private String productName;
    private Float productPrice;
    private String payerId;

    public Payment() {
        paymentId = "none";
        productName = "item";
        productPrice = 0.0f;
        payerId = "";
    }

    public Payment(String productNameParam, Float productPriceParam) {
        paymentId = "";
        productName = productNameParam;
        productPrice = productPriceParam;
        payerId = "";

    }

    public Payment(String paymentIdParam, String productNameParam, Float productPriceParam) {
        paymentId = paymentIdParam;
        productName = productNameParam;
        productPrice = productPriceParam;
        payerId = "";
    }

    public Payment(String paymentIdParam, String productNameParam, Float productPriceParam, String payerIdParam) {
        paymentId = paymentIdParam;
        productName = productNameParam;
        productPrice = productPriceParam;
        payerId = payerIdParam;
    }

    public String getPaymentId() {
        return paymentId;
    }

    public String getProductName() {
        return productName;
    }

    public Float getProductPrice() {
        return productPrice;
    }

    public String getPayerId() {
        return payerId;
    }

    public void setPaymentId(String paymentId) {
        this.paymentId = paymentId;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public void setProductPrice(Float productPrice) {
        this.productPrice = productPrice;
    }

    public void setPayerId(String payerId) {
        this.payerId = payerId;
    }

    @Override
    public String toString() {
        return "Id: " + paymentId + " Name: " + productName + " Price: " + productPrice + " PayerId: " + payerId;
    }

    protected Payment(Parcel in) {
        paymentId = in.readString();
        productName = in.readString();
        productPrice = in.readFloat();
        payerId = in.readString();
    }

    public static final Creator<Payment> CREATOR = new Creator<Payment>() {
        @Override
        public Payment createFromParcel(Parcel in) {
            return new Payment(in);
        }

        @Override
        public Payment[] newArray(int size) {
            return new Payment[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(paymentId);
        dest.writeString(productName);
        dest.writeFloat(productPrice);
        dest.writeString(payerId);
    }

    @Override
    public boolean equals(Object obj) {
        if(obj instanceof Payment)
        {
            Payment otherPayment = (Payment) obj;
            if (!otherPayment.getProductName().equals(this.getProductName())){
                return false;
            }

            if (!otherPayment.getProductPrice().equals(this.getProductPrice())) {
                return false;
            }

            return true;
        }
        else
        {
            return false;
        }
    }
}
