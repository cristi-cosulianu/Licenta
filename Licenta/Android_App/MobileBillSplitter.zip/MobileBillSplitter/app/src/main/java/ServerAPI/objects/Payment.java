package ServerAPI.objects;

import android.os.Parcel;
import android.os.Parcelable;

public class Payment implements Parcelable {
    private String productName;
    private Float productPrice;

    public Payment() {
        productName = "item";
        productPrice = 0.0f;
    }

    public Payment(String productNameParam, Float productPriceParam) {
        productName = productNameParam;
        productPrice = productPriceParam;
    }

    public String getProductName() {
        return productName;
    }

    public Float getProductPrice() {
        return productPrice;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public void setProductPrice(Float productPrice) {
        this.productPrice = productPrice;
    }

    @Override
    public String toString() {
        return "Name: " + productName + " Price: " + productPrice;
    }

    protected Payment(Parcel in) {
        productName = in.readString();
        productPrice = in.readFloat();
    }

    public static final Creator<Payment> CREATOR = new Creator<Payment>() {
        @Override
        public Payment createFromParcel(Parcel in) {
            return new Payment(in);
        }

        @Override
        public Payment[] newArray(int size) {
            return new Payment[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(productName);
        dest.writeFloat(productPrice);
    }

    @Override
    public boolean equals(Object obj) {
        if(obj instanceof Payment)
        {
            Payment otherPayment = (Payment) obj;
            if (!otherPayment.getProductName().equals(this.getProductName())){
                return false;
            }

            if (!otherPayment.getProductPrice().equals(this.getProductPrice())) {
                return false;
            }

            return true;
        }
        else
        {
            return false;
        }
    }
}
