package com.example.mobilebillsplitter.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.example.mobilebillsplitter.adapters.PaymentsAdapter;
import com.example.mobilebillsplitter.R;
import com.example.mobilebillsplitter.utils.PreferencesController;

import java.util.List;

import ServerAPI.objects.Bill;
import ServerAPI.objects.Payment;

public class EditResultsActivity extends AppCompatActivity {

    private Button doneEditingButton;

    private ListView listView;

    private PaymentsAdapter listAdapter;

    private Bill bill;

    private EditText titleEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_results);

        getSupportActionBar().setTitle("Edit results page");

        getIntentData();

        initializeListView();

        initializeDoneButton();

        titleEditText = findViewById(R.id.titleEditTextID);

    }

    private void getIntentData() {
        Bundle bundle = getIntent().getExtras();
        String billKey = getApplicationContext().getResources().getString(R.string.EXTRA_BILL_KEY);
        bill = bundle.getParcelable(billKey);
    }

    private void initializeListView() {
        listAdapter = new PaymentsAdapter(this, bill);
        listView = findViewById(R.id.editPaymentsListViewID);
        listView.setAdapter(listAdapter);
        listAdapter.notifyDataSetChanged();
    }

    private void initializeDoneButton() {
        doneEditingButton = findViewById(R.id.editProductsDoneButtonID);
        doneEditingButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (updateBillObject()) {
                    Intent intent = new Intent(EditResultsActivity.this, PersonsActivity.class);
                    Bundle billBundle = bill.createBillBundle(getApplicationContext());
                    PreferencesController.saveSelectedPerson(getApplicationContext(), 0);
                    intent.putExtras(billBundle);
                    startActivity(intent);
                }

            }
        });
    }

    private boolean updateBillObject() {
        String billTitle = titleEditText.getText().toString();
        if (billTitle.length() > 0) {
            bill.setBillTitle(titleEditText.getText().toString());
            updatePayments();
            return true;
        } else {
            Toast.makeText(getApplicationContext(), "Please insert a title!", Toast.LENGTH_LONG).show();
            return false;
        }
    }

    private void updatePayments() {

        List<Payment> paymentList = bill.getPaymentsList();
        for (int i = 0; i < listView.getChildCount(); i++) {
            View rowView = listView.getChildAt(i);
            EditText productNameView = rowView.findViewById(R.id.productNameID);
            EditText productPriceView = rowView.findViewById(R.id.productPriceID);
            String productName = productNameView.getText().toString();
            Float productPrice = Float.valueOf(productPriceView.getText().toString());
            if (!productName.equals(paymentList.get(i).getProductName()) || !productPrice.equals(paymentList.get(i).getProductPrice())) {
                Payment newPayment = new Payment(productName, productPrice);
                paymentList.set(i, newPayment);
            }
        }
    }
}
