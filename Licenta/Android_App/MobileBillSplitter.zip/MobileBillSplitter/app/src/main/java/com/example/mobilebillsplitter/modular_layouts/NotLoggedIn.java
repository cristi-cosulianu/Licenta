package com.example.mobilebillsplitter.modular_layouts;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.mobilebillsplitter.R;

import ServerAPI.requests.PersonRequests;

public class NotLoggedIn {

    private EditText usernameInput;
    private Button registerButton;

    public void initialize(final Context context, final AppCompatActivity currentActivity) {

        usernameInput = currentActivity.findViewById(R.id.registerNameInputID);
        registerButton = currentActivity.findViewById(R.id.registerButtonID);
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PersonRequests personRequests = new PersonRequests(context);
                String personName = usernameInput.getText().toString();
                personRequests.postPersonByName(personName);
            }
        });
    }
}
