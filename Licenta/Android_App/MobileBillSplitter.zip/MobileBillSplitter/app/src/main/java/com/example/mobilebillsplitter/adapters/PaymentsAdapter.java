package com.example.mobilebillsplitter.adapters;

import android.app.Activity;
import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.TextView;

import com.example.mobilebillsplitter.utils.PreferencesController;
import com.example.mobilebillsplitter.R;
import com.example.mobilebillsplitter.activities.AssignPaymentsActivity;
import com.example.mobilebillsplitter.activities.EditResultsActivity;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.List;

import ServerAPI.objects.Bill;
import ServerAPI.objects.Payment;
import ServerAPI.objects.Person;

public class PaymentsAdapter extends ArrayAdapter {

    private Activity context;

    private Bill bill;

    private TextView totalSumTextView;
    private Float totalSumValue = 0f;

    private int[] listOfButtonLayouts = new int[] {
            R.drawable.button_color0,
            R.drawable.button_color1,
            R.drawable.button_color2,
            R.drawable.button_color3,
            R.drawable.button_color4,
            R.drawable.button_color5,
            R.drawable.button_color6,
            R.drawable.button_color7,
            R.drawable.button_color8,
            R.drawable.button_color9
    };

    public PaymentsAdapter(Activity contextParam, Bill billParam) {
        super(contextParam, R.layout.row_payment, billParam.getPaymentsList());
        context = contextParam;
        bill = billParam;
        if (context.getClass() == AssignPaymentsActivity.class) {
            totalSumTextView = context.findViewById(R.id.totalSumTextViewID);
        }
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final int currPosition = position;
        LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View rowView = inflater.inflate(R.layout.row_payment, null, true);
        final EditText productTextView = rowView.findViewById(R.id.productNameID);
        final EditText priceTextView = rowView.findViewById(R.id.productPriceID);

        productTextView.setText(bill.getPaymentsList().get(position).getProductName());
        priceTextView.setText(bill.getPaymentsList().get(position).getProductPrice().toString());


        // Add listener that will save text on change.
        if (context.getClass() == EditResultsActivity.class) {
            addEditTextSaveListener(productTextView, position);
            addEditTextSaveListener(priceTextView, position);
        }

        if (context.getClass() == AssignPaymentsActivity.class) {
            productTextView.setFocusable(false);
            priceTextView.setFocusable(false);

            if (bill.existPaymentInPaymentsToPerson(bill.getPaymentsList().get(currPosition))) {
                Person assignedPerson = bill.getPersonForPaymentInPaymentsToPerson(bill.getPaymentsList().get(currPosition));
                Integer assignedPersonIndex = (bill.getPersonsList().indexOf(assignedPerson));
                productTextView.setBackgroundResource(listOfButtonLayouts[assignedPersonIndex]);
                priceTextView.setBackgroundResource(listOfButtonLayouts[assignedPersonIndex]);
            } else {
                productTextView.setBackgroundResource(R.drawable.regular_field);
                priceTextView.setBackgroundResource(R.drawable.regular_field);
            }

            // For the rows that are recreated to still be selected at recreation.
            if (PreferencesController.isPaymentSelected(getContext(), bill.getPaymentsList().size(), currPosition)) {
                // Set selected false here to be set as true in changePaymentsBackground.
                productTextView.setSelected(false);
                priceTextView.setSelected(false);
                changePaymentsBackground(productTextView, priceTextView, currPosition);
            }

            productTextView.setClickable(true);
            productTextView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    changePaymentsBackground(productTextView, priceTextView, currPosition);
                }
            });

            priceTextView.setClickable(true);
            priceTextView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    changePaymentsBackground(productTextView, priceTextView, currPosition);
                }
            });
        }


        return rowView;
    }

    private void changePaymentsBackground(EditText productTextView, EditText priceTextView, int currPosition) {
        if (productTextView.isSelected()) {
            productTextView.setSelected(false);
            priceTextView.setSelected(false);
            subtractFromTotalPrice(currPosition);

            if (bill.existPaymentInPaymentsToPerson(bill.getPaymentsList().get(currPosition))) {
                Person assignedPerson = bill.getPersonForPaymentInPaymentsToPerson(bill.getPaymentsList().get(currPosition));
                Integer assignedPersonIndex = (bill.getPersonsList().indexOf(assignedPerson));
                productTextView.setBackgroundResource(listOfButtonLayouts[assignedPersonIndex]);
                priceTextView.setBackgroundResource(listOfButtonLayouts[assignedPersonIndex]);
            } else {
                productTextView.setBackgroundResource(R.drawable.regular_field);
                priceTextView.setBackgroundResource(R.drawable.regular_field);
            }

            PreferencesController.removeSelectedPayment(getContext(), currPosition);

        } else if(!productTextView.isSelected() && PreferencesController.isPersonSelected(getContext())) {
            productTextView.setSelected(true);
            priceTextView.setSelected(true);
            addToTotalPrice(currPosition);

            productTextView.setBackgroundResource(R.drawable.selected_field);
            priceTextView.setBackgroundResource(R.drawable.selected_field);

            PreferencesController.saveSelectedPayment(getContext(), currPosition);

        }
    }

    private void addToTotalPrice(int currPosition) {
        totalSumValue += bill.getPaymentsList().get(currPosition).getProductPrice();
        String totalSumText = context.getResources().getString(R.string.total_sum_text);
        try {
            DecimalFormat decimalFormat = new DecimalFormat("#.##");
            decimalFormat.setRoundingMode(RoundingMode.HALF_UP);
            totalSumText += " " + decimalFormat.format(totalSumValue);
        } catch (Exception e) {
            Log.d("PAYMENTS", "Error at converting from float to string!");
        }
        totalSumTextView.setText(totalSumText);
    }

    private void subtractFromTotalPrice(int currPosition) {
        totalSumValue -= bill.getPaymentsList().get(currPosition).getProductPrice();
        String totalSumText = context.getResources().getString(R.string.total_sum_text);
        try {
            DecimalFormat decimalFormat = new DecimalFormat("#.##");
            decimalFormat.setRoundingMode(RoundingMode.HALF_UP);
            totalSumText += " " + decimalFormat.format(totalSumValue);
        } catch (Exception e) {
            Log.d("PAYMENTS", "Error at converting from float to string!");
        }
        totalSumTextView.setText(totalSumText);
    }

    @Override
    public void notifyDataSetChanged() {
        super.notifyDataSetChanged();
    }

    private void addEditTextSaveListener(final EditText editText, final int position) {
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.length() != 0) {
                    List<Payment> paymentList = bill.getPaymentsList();
                    Payment payment = paymentList.get(position);
                    if(editText.getId() == R.id.productNameID) {
                        payment.setProductName(s.toString());
                    } else {
                        payment.setProductPrice(Float.valueOf(s.toString()));
                    }
                    paymentList.set(position, payment);
                    bill.setPaymentsList(paymentList);
                }
            }
        });
    }
}
