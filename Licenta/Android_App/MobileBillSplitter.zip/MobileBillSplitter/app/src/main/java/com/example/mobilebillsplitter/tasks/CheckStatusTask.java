package com.example.mobilebillsplitter.tasks;

import android.content.Context;
import android.os.AsyncTask;

import com.example.mobilebillsplitter.interfaces.OnDataReceive;

import java.util.List;

import ServerAPI.objects.Person;

public class CheckStatusTask extends AsyncTask<Void, Void, Void> {
    private List<Person> personList;
    private Context context;

    private OnDataReceive onDataReceive;

    public CheckStatusTask(Context context, List<Person> personList ){
        // AICI PRIMESC CE AM NEVEOIE CA SA FAC TASK-UL.
        this.personList = personList;
        this.context = context;

    }
    @Override
    protected Void doInBackground(Void... voids) {
        // LEAGA ACTIVITAREA DE ON DATA RECEIVE.
        onDataReceive = (OnDataReceive) context;
        // AICI FAC TASKUL SI DAU REZULTATUL CA PARAM LA OnDataReceive.
        onDataReceive.OnDataReceive(personList);
        return null;
    }
}
