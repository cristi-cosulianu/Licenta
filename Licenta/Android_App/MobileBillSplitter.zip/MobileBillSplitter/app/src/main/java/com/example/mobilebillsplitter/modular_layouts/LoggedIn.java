package com.example.mobilebillsplitter.modular_layouts;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.mobilebillsplitter.utils.PreferencesController;
import com.example.mobilebillsplitter.R;

import ServerAPI.requests.PersonRequests;

public class LoggedIn {

    private TextView registeredMessageView;

    private Button unregisterButton;

    public void initialize(final Context context, final AppCompatActivity currentActivity) {

        final String username = PreferencesController.getUserLoggedIn(context);

        registeredMessageView = currentActivity.findViewById(R.id.registeredMessageID);
        registeredMessageView.setText(context.getString(R.string.registered_message) + " " + username);
        unregisterButton = currentActivity.findViewById(R.id.unregisterButtonID);
        unregisterButton.setPadding(30, 0,30,0);
        unregisterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PersonRequests personRequests = new PersonRequests(context);
                personRequests.deletePerson(username);
            }
        });
    }
}
