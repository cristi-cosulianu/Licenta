package com.example.mobilebillsplitter.adapters;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;

import com.example.mobilebillsplitter.utils.PreferencesController;
import com.example.mobilebillsplitter.R;
import com.example.mobilebillsplitter.activities.MainActivity;
import com.example.mobilebillsplitter.activities.SelectPersonsActivity;

import java.util.List;

import ServerAPI.objects.Bill;
import ServerAPI.objects.Person;

public class PersonsAdapter extends ArrayAdapter {

    private Bill bill;

    private Activity context;

    private int[] listOfButtonLayouts = new int[] {
            R.drawable.button_color0,
            R.drawable.button_color1,
            R.drawable.button_color2,
            R.drawable.button_color3,
            R.drawable.button_color4,
            R.drawable.button_color5,
            R.drawable.button_color6,
            R.drawable.button_color7,
            R.drawable.button_color8,
            R.drawable.button_color9
    };


    public PersonsAdapter(Activity contextParam, Bill billParam) {
        super(contextParam, R.layout.row_payment, billParam.getPersonsList());
        context = contextParam;
        bill = billParam;
    }

        @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final int currPosition = position;
        LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.row_person, null, true);

        final Button personNameButton = rowView.findViewById(R.id.addPersonsRowNameId);

        if (context.getClass() == SelectPersonsActivity.class) {

            if (bill.existPersonInPaymentsToPerson(bill.getPersonsList().get(currPosition))) {
                personNameButton.setBackgroundResource(listOfButtonLayouts[currPosition]);
            } else {
                personNameButton.setBackgroundResource(R.drawable.regular_field);
            }

            final int selectedPerson = PreferencesController.getSelectedPerson(getContext());
            if (currPosition == selectedPerson) {
                personNameButton.setSelected(false);
                changePersonBackground(personNameButton, currPosition);
            }

            personNameButton.setClickable(true);
            personNameButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    changePersonBackground(personNameButton, currPosition);
                }
            });
        }

        Person person = bill.getPersonsList().get(position);
        personNameButton.setText(person.getName());

        return rowView;
    }

    private void changePersonBackground(Button personNameButton, int currPosition) {
        int selectedPerson = PreferencesController.getSelectedPerson(getContext());
        if (selectedPerson == -1) {
            selectedPerson = currPosition;
        }

        if (personNameButton.isSelected()) {

            personNameButton.setSelected(false);
            if (bill.existPersonInPaymentsToPerson(bill.getPersonsList().get(currPosition))) {
                personNameButton.setBackgroundResource(listOfButtonLayouts[currPosition]);
            } else {
                personNameButton.setBackgroundResource(R.drawable.regular_field);
            }
            PreferencesController.removeSelectedPerson(getContext());

        } else if(!personNameButton.isSelected() && selectedPerson == currPosition) {

            personNameButton.setSelected(true);
            personNameButton.setBackgroundResource(R.drawable.selected_field);
            PreferencesController.saveSelectedPerson(getContext(), currPosition);

        }
    }


        @Override
    public void add(Object object) {
        super.add(object);
    }

    public List<Person> getListOfPersons() {
        return bill.getPersonsList();
    }

    @Override
    public void notifyDataSetChanged() {
        super.notifyDataSetChanged();
    }

}
