package ServerAPI.requests;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import ServerAPI.ClientBuilder;
import ServerAPI.MBSServerApi;
import ServerAPI.objects.Bill;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BillRequests {

    private Context context;
    private MBSServerApi service;

    public BillRequests(Context context) {
        this.context = context;
        service = ClientBuilder.createService();
    }

    public void getBill(final String billId, final Intent intent) {
        Call<Bill> call = service.getBillById(billId);

        call.enqueue(new Callback<Bill>() {
            @Override
            public void onResponse(Call<Bill> call, Response<Bill> response) {
                Bill responseBill = response.body();
                Bundle billBundle = responseBill.createBillBundle(context);
                intent.putExtras(billBundle);
                context.startActivity(intent);
                Toast.makeText(context, "We got the bill!", Toast.LENGTH_LONG).show();
            }

            @Override
            public void onFailure(Call<Bill> call, Throwable t) {
                Toast.makeText(context, "Error while getting the new bill!", Toast.LENGTH_LONG).show();
            }
        });
    }

    public void postNewBill(final Bill bill, final Intent intent) {

        Call<Bill> call = service.postBill(bill);

        call.enqueue(new Callback<Bill>() {
            @Override
            public void onResponse(Call<Bill> call, Response<Bill> response) {
                Bill responseBill = response.body();
                Bundle billBundle = responseBill.createBillBundle(context);
                intent.putExtras(billBundle);
                context.startActivity(intent);
            }

            @Override
            public void onFailure(Call<Bill> call, Throwable t) {
                Toast.makeText(context, "Error while posting the new bill!", Toast.LENGTH_LONG).show();
            }
        });
    }
}
