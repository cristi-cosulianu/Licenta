package com.example.mobilebillsplitter.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.example.mobilebillsplitter.adapters.PersonsAdapter;
import com.example.mobilebillsplitter.utils.PreferencesController;
import com.example.mobilebillsplitter.R;

import ServerAPI.objects.Bill;

public class SelectPersonsActivity extends AppCompatActivity {
    private Bill bill;

    private PersonsAdapter personsListAdapter;
    private ListView personsListView;

    private Button assignPaymentsButton;
    private Button doneAssigningButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_person);

        PreferencesController.clearPreferences(getApplicationContext());

        getSupportActionBar().setTitle("Assign payments page");

        getIntentData();

        initializePersonsListView();

        initializeButtons();

    }

    private void initializeButtons() {
        doneAssigningButton = findViewById(R.id.doneAssigningPersonsButtonID);
        if (bill != null && bill.getPaymentToPersonList().size() == bill.getPaymentsList().size()) {
            doneAssigningButton.setEnabled(true);
            doneAssigningButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(SelectPersonsActivity.this, BillStatusActivity.class);
//                    Intent intent = new Intent(MainActivity.this, BillStatusActivity.class);
                    Bundle billBundle = bill.createBillBundle(getApplicationContext());
                    intent.putExtras(billBundle);
                    getApplicationContext().startActivity(intent);
                }
            });
        } else {
            doneAssigningButton.setEnabled(false);
        }

        assignPaymentsButton = findViewById(R.id.toAssigningPaymentsButtonID);
        assignPaymentsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (PreferencesController.isPersonSelected(getApplicationContext())) {
                    Intent intent = new Intent(SelectPersonsActivity.this, AssignPaymentsActivity.class);
//                    Intent intent = new Intent(MainActivity.this, AssignPaymentsActivity.class);
                    Bundle billBundle = bill.createBillBundle(getApplicationContext());
                    intent.putExtras(billBundle);
                    getApplicationContext().startActivity(intent);
                } else {
                    Toast.makeText(getApplicationContext(), "Please select a person!", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

    private void getIntentData() {
        Bundle bundle = getIntent().getExtras();
        String billKey = getApplicationContext().getResources().getString(R.string.EXTRA_BILL_KEY);
        try {
            bill = bundle.getParcelable(billKey);
        } catch (Exception e) {
            Log.v("EXCEPTION", e.toString());
        }
    }

    private void initializePersonsListView() {
        personsListAdapter = new PersonsAdapter(this, bill);
        personsListView = findViewById(R.id.assignPersonsListViewID);
        personsListView.setAdapter(personsListAdapter);
        personsListAdapter.notifyDataSetChanged();
    }

}