package com.example.mobilebillsplitter.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mobilebillsplitter.adapters.PersonsAdapter;
import com.example.mobilebillsplitter.utils.PreferencesController;
import com.example.mobilebillsplitter.R;

import java.util.ArrayList;
import java.util.List;

import ServerAPI.objects.Bill;
import ServerAPI.objects.Payment;
import ServerAPI.objects.Person;

public class PersonsActivity extends AppCompatActivity {

    private TextView billIdView;

    private Button doneAddingButton;

    private ListView listView;

    private PersonsAdapter listAdapter;

    private Bill bill;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_persons);

        getSupportActionBar().setTitle("Add persons page");

        // For tests.
        initializeBills();

        // Functie care sa verifice daca s-au alaturat noi persoane.

        // Uncomment this after tests.
//        getIntentData();

        initializeBillIdView();

        initializeListView();

        initializeDoneButton();

    }

    private void initializeBillIdView() {
        billIdView = findViewById(R.id.billIdTextViewID);
        String billIdText = getApplicationContext().getResources().getString(R.string.share_bill_text);
        billIdText += " " + bill.getBillId();
        billIdView.setText(billIdText);
    }

    private void initializeListView() {
        listAdapter = new PersonsAdapter(this, bill);
        listAdapter.add(PreferencesController.getPersonLoggedIn(getApplicationContext()));
        listView = findViewById(R.id.addPersonsListViewID);
        listView.setAdapter(listAdapter);
    }

    private void getIntentData() {
        Bundle bundle = getIntent().getExtras();
        String billKey = getApplicationContext().getResources().getString(R.string.EXTRA_BILL_KEY);
        bill = bundle.getParcelable(billKey);
    }

    private void initializeDoneButton() {
        doneAddingButton = findViewById(R.id.addPersonsDoneButtonID);
        doneAddingButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (updateBillObject()) {
//                    Intent intent = new Intent(MainActivity.this, AssignPaymentsActivity.class);
                    Intent intent = new Intent(PersonsActivity.this, AssignPaymentsActivity.class);
                    Bundle billBundle = bill.createBillBundle(getApplicationContext());
                    PreferencesController.saveSelectedPerson(getApplicationContext(), 0);
                    intent.putExtras(billBundle);
                    startActivity(intent);
                }

            }
        });
    }


    private boolean updateBillObject() {
        List<Person> listOfPersons = listAdapter.getListOfPersons();
        if (listOfPersons != null && listOfPersons.size() > 0) {
            bill.setPersonsList(listOfPersons);
            return true;
        } else {
            Toast.makeText(getApplicationContext(), "Please add one person!", Toast.LENGTH_LONG).show();
            return false;
        }
    }


    private void initializeBills() {
        // Request the bills where this person is initiator.

        Person person1 = new Person("id", "Eugen");
        Person person2 = new Person("id", "Costel");
        Payment payment1 = new Payment("Costite", (float) 44.0);
        Payment payment2 = new Payment("Burger", (float) 27.5);
        Payment payment3 = new Payment("Cartofi prajiti", (float) 8.5);
        Payment payment4 = new Payment("Supa de legume", (float) 8.0);
        List<Person> personList = new ArrayList<>();
        personList.add(person1);
        personList.add(person2);
        personList.add(person2);
        personList.add(person2);

        List<Payment> paymentList = new ArrayList<>();
        paymentList.add(payment1);
        paymentList.add(payment2);
        paymentList.add(payment3);
        paymentList.add(payment4);
        paymentList.add(payment1);
        paymentList.add(payment2);
        paymentList.add(payment3);
        paymentList.add(payment4);
        paymentList.add(payment1);
        paymentList.add(payment2);
        paymentList.add(payment3);
        paymentList.add(payment4);

        bill = new Bill(paymentList , personList, "Mammamia");
        bill.setBillId("5ce19b85da69af4e2ca3393a");
        bill.setInitiatorName("Cristi");

    }
}
