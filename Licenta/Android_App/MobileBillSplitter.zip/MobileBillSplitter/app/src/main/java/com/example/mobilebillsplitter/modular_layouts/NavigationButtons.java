package com.example.mobilebillsplitter.modular_layouts;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import com.example.mobilebillsplitter.activities.BillMainActivity;
import com.example.mobilebillsplitter.activities.MainActivity;
import com.example.mobilebillsplitter.activities.PaymentsMainActivity;
import com.example.mobilebillsplitter.R;
import com.example.mobilebillsplitter.activities.SettingsMainActivity;

public class NavigationButtons {
    public void initialize(Context context, AppCompatActivity currentActivity) {

//        Toast.makeText(context, "NAV BUTTONS INITIALIZED", Toast.LENGTH_SHORT).show();

        Button homeButton = currentActivity.findViewById(R.id.homeButtonID);
        Button billButton = currentActivity.findViewById(R.id.billsButtonID);
        Button paymentsButton = currentActivity.findViewById(R.id.paymentsButtonID);
        Button settingsButton = currentActivity.findViewById(R.id.settingsButtonID);

        String activityName = currentActivity.getClass().getSimpleName();

        switch (activityName) {
            case "MainActivity":
                homeButton.setBackgroundResource(R.drawable.navigation_button_blue);
                addListener(context, billButton, currentActivity, BillMainActivity.class);
                addListener(context, paymentsButton, currentActivity, PaymentsMainActivity.class);
                addListener(context, settingsButton, currentActivity, SettingsMainActivity.class);
                break;
            case "BillMainActivity":
                billButton.setBackgroundResource(R.drawable.navigation_button_blue);
                addListener(context, homeButton, currentActivity, MainActivity.class);
                addListener(context, paymentsButton, currentActivity, PaymentsMainActivity.class);
                addListener(context, settingsButton, currentActivity, SettingsMainActivity.class);
                break;
            case "PaymentsMainActivity":
                paymentsButton.setBackgroundResource(R.drawable.navigation_button_blue);
                addListener(context, billButton, currentActivity, BillMainActivity.class);
                addListener(context, homeButton, currentActivity, MainActivity.class);
                addListener(context, settingsButton, currentActivity, SettingsMainActivity.class);
                break;
            case "SettingsMainActivity":
                settingsButton.setBackgroundResource(R.drawable.navigation_button_blue);
                addListener(context, billButton, currentActivity, BillMainActivity.class);
                addListener(context, paymentsButton, currentActivity, PaymentsMainActivity.class);
                addListener(context, homeButton, currentActivity, MainActivity.class);
                break;
        }

//        Toast.makeText(context,"" + currentActivity.getClass().getSimpleName(), Toast.LENGTH_LONG).show();

    }

    private void addListener(final Context context, Button button, final AppCompatActivity fromActivity, final Class toActivityClass) {
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(fromActivity, toActivityClass);
                fromActivity.startActivity(intent);
                fromActivity.overridePendingTransition(0, 0);

            }
        });
    }
}
