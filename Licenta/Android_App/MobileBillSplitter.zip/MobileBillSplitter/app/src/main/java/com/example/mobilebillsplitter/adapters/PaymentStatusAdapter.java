package com.example.mobilebillsplitter.adapters;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.mobilebillsplitter.R;

import ServerAPI.objects.Bill;

public class PaymentStatusAdapter extends ArrayAdapter {

    private Bill bill;

    private Activity context;

    public PaymentStatusAdapter(Activity contextParam, Bill billParam) {
        super(contextParam, R.layout.row_person_status, billParam.getPersonsList());
        context = contextParam;
        bill = billParam;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final int currPosition = position;
        LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.row_person_status, null, true);

        TextView personNameEditText = rowView.findViewById(R.id.rowBillTitleID);
        ImageView personStatusImageView = rowView.findViewById(R.id.imageBillStatusID);
        personNameEditText.setText(bill.getPersonsList().get(currPosition).getName());
        personStatusImageView.setBackgroundResource(R.drawable.ic_pending);

        return rowView;
    }
}
