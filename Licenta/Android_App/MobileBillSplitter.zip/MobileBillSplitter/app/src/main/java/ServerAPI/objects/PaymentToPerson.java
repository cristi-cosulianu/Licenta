package ServerAPI.objects;

import android.os.Parcel;
import android.os.Parcelable;

public class PaymentToPerson implements Parcelable {
    private Payment payment;
    private Person person;

    public PaymentToPerson(Payment paymentParam, Person personParam) {
        payment = paymentParam;
        person = personParam;
    }

    public Payment getPayment() {
        return payment;
    }

    public Person getPerson() {
        return person;
    }

    public void setPayment(Payment payment) {
        this.payment = payment;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    @Override
    public String toString() {
        return "Name: " + person.getName() + " Payment: " + payment.toString();
    }

    protected PaymentToPerson(Parcel in) {
        payment = in.readTypedObject(Payment.CREATOR);
        person = in.readTypedObject(Person.CREATOR);
    }

    public static final Parcelable.Creator<PaymentToPerson> CREATOR = new Parcelable.Creator<PaymentToPerson>() {
        @Override
        public PaymentToPerson createFromParcel(Parcel in) {
            return new PaymentToPerson(in);
        }

        @Override
        public PaymentToPerson[] newArray(int size) {
            return new PaymentToPerson[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeTypedObject(payment, flags);
        dest.writeTypedObject(person, flags);
    }

    @Override
    public boolean equals(Object obj) {
        if(obj instanceof PaymentToPerson)
        {
            PaymentToPerson otherPayment = (PaymentToPerson) obj;
            if (!otherPayment.getPerson().equals(this.getPerson())){
                return false;
            }

            if (!otherPayment.getPayment().equals(this.getPayment())) {
                return false;
            }

            return true;
        }
        else
        {
            return false;
        }
    }
}
