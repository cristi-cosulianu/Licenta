package ServerAPI;

import java.util.List;

import ServerAPI.objects.Bill;
import ServerAPI.objects.Payment;
import ServerAPI.objects.Person;
import ServerAPI.responses.MessageResponse;
import okhttp3.MultipartBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Path;

public interface MBSServerApi {
    @GET("persons/")
    Call<List<Person>> getAllPersons();

    @GET("persons/id/{personId}")
    Call<Person> getPersonById(@Path("personId") String personId);

    @GET("persons/name/{personName}")
    Call<Person> getPersonByName(@Path("personName") String personName);

    @GET("bills/{billId}")
    Call<Bill> getBillById(@Path("billId") String billId);

    @POST("persons/name/{personName}")
    Call<Person> postPersonByName(@Path("personName") String personName);

    @POST("bills/")
    Call<Bill> postBill(@Body Bill bill);

    @DELETE("persons/name/{personName}")
    Call<MessageResponse> deletePersonByName(@Path("personName") String personName);

    @Multipart
    @POST("runscript")
    Call<List<Payment>> uploadImage(
        @Part MultipartBody.Part image
    );
}