package com.example.mobilebillsplitter.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import com.example.mobilebillsplitter.adapters.PaymentsAdapter;
import com.example.mobilebillsplitter.utils.PreferencesController;
import com.example.mobilebillsplitter.R;

import java.util.List;

import ServerAPI.objects.Bill;
import ServerAPI.objects.Payment;
import ServerAPI.objects.PaymentToPerson;
import ServerAPI.objects.Person;

public class AssignPaymentsActivity extends AppCompatActivity {
    private Bill bill;

    private PaymentsAdapter paymentsListAdapter;
    private ListView paymentsListView;

    private Button doneAssigningButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assign_payments);

        getSupportActionBar().setTitle("Assign payments page");

        getIntentData();

        initializePaymentsListView();

        initializeButtons();

    }

    private void initializeButtons() {
        doneAssigningButton = findViewById(R.id.doneAssigningPaymentsButtonID);
        doneAssigningButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//
//                updateBillObject();
//
//                Intent intent = new Intent(AssignPaymentsActivity.this, SelectPersonsActivity.class);
//                Intent intent = new Intent(AssignPaymentsActivity.this, MainActivity.class);
//
//                Bundle billBundle = bill.createBillBundle(getApplicationContext());
//                intent.putExtras(billBundle);
//                getApplicationContext().startActivity(intent);


            }
        });
    }

    private void getIntentData() {
        Bundle bundle = getIntent().getExtras();
        String billKey = getApplicationContext().getResources().getString(R.string.EXTRA_BILL_KEY);
        try {
            bill = bundle.getParcelable(billKey);
        } catch (Exception e) {
            Log.v("EXCEPTION", e.toString());
        }
    }

    private void initializePaymentsListView() {
        paymentsListAdapter = new PaymentsAdapter(this, bill);
        paymentsListView = findViewById(R.id.assignPersonsListViewID);
        paymentsListView.setAdapter(paymentsListAdapter);
        paymentsListAdapter.notifyDataSetChanged();
    }

    private void updateBillObject() {
        Integer selectedPersonIndex = PreferencesController.getSelectedPerson(getApplicationContext());
        Person selectedPerson = bill.getPersonsList().get(selectedPersonIndex);

        Integer numberOfPayments = bill.getPaymentsList().size();
        List<Integer> selectedPaymentsLines = PreferencesController.getSelectedPayments(getApplicationContext(), numberOfPayments);
        List<Payment> paymentsList =  bill.getPaymentsList();
        for (Integer index : selectedPaymentsLines) {
            Payment selectedPayment = paymentsList.get(index);
            if (!bill.existPaymentInPaymentsToPerson(selectedPayment)) {
                PaymentToPerson paymentToPerson = new PaymentToPerson(selectedPayment, selectedPerson);
                bill.addPaymentToPerson(paymentToPerson);
            }
        }
    }
}
