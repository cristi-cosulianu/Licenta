package com.example.mobilebillsplitter.activities;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mobilebillsplitter.adapters.PaymentsAdapter;
import com.example.mobilebillsplitter.services.GooglePay;
import com.example.mobilebillsplitter.utils.PreferencesController;
import com.example.mobilebillsplitter.R;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.wallet.AutoResolveHelper;
import com.google.android.gms.wallet.IsReadyToPayRequest;
import com.google.android.gms.wallet.PaymentData;
import com.google.android.gms.wallet.PaymentDataRequest;
import com.google.android.gms.wallet.PaymentsClient;
import com.google.android.gms.wallet.Wallet;
import com.google.android.gms.wallet.WalletConstants;
import com.google.gson.JsonArray;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;
import java.util.Optional;

import ServerAPI.objects.Bill;
import ServerAPI.objects.Payment;
import ServerAPI.objects.PaymentToPerson;
import ServerAPI.objects.Person;

public class AssignPaymentsActivity extends AppCompatActivity {
    private Bill bill;

    private PaymentsAdapter paymentsListAdapter;
    private ListView paymentsListView;

    private Button mGooglePayButton;

    private PaymentsClient mPaymentsClient;

    /** A constant integer you define to track a request for payment data activity */
    private static final int LOAD_PAYMENT_DATA_REQUEST_CODE = 42;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assign_payments);

        getSupportActionBar().setTitle("Assign payments page");

        getIntentData();

        initializePaymentsListView();

        // initialize a Google Pay API client for an environment suitable for testing
        mPaymentsClient =
                Wallet.getPaymentsClient(
                this,
                new Wallet.WalletOptions.Builder()
                .setEnvironment(WalletConstants.ENVIRONMENT_TEST)
                    .build());

        possiblyShowGooglePayButton();
    }

    /**
     * Determine the viewer's ability to pay with a payment method supported by your app and display a
     * Google Pay payment button
     *
     * @see <a
     *     href="https://developers.google.com/android/reference/com/google/android/gms/wallet/PaymentsClient#isReadyToPay(com.google.android.gms.wallet.IsReadyToPayRequest)">PaymentsClient#IsReadyToPay</a>
     */
    private void possiblyShowGooglePayButton() {
        final Optional<JSONObject> isReadyToPayJson = GooglePay.getIsReadyToPayRequest();
        if (!isReadyToPayJson.isPresent()) {
            return;
        }
        IsReadyToPayRequest request = IsReadyToPayRequest.fromJson(isReadyToPayJson.get().toString());
        if (request == null) {
            return;
        }
        Task<Boolean> task = mPaymentsClient.isReadyToPay(request);
        task.addOnCompleteListener(
                new OnCompleteListener<Boolean>() {
                    @Override
                    public void onComplete(@NonNull Task<Boolean> task) {
                        try {
                            boolean result = task.getResult(ApiException.class);
                            if (result) {
                                // show Google as a payment option
                                mGooglePayButton = findViewById(R.id.googlePayButtonID);
                                mGooglePayButton.setOnClickListener(
                                        new View.OnClickListener() {
                                            @Override
                                            public void onClick(View view) {
                                                requestPayment(view);
                                            }
                                        });
                                mGooglePayButton.setVisibility(View.VISIBLE);
                            }
                        } catch (ApiException exception) {
                            // handle developer errors
                        }
                    }
                });
    }

    /**
     * Display the Google Pay payment sheet after interaction with the Google Pay payment button
     *
     * @param view optionally uniquely identify the interactive element prompting for payment
     */
    public void requestPayment(View view) {
        Optional<JSONObject> paymentDataRequestJson = GooglePay.getPaymentDataRequest();
        if (!paymentDataRequestJson.isPresent()) {
            return;
        }
        PaymentDataRequest request =
                PaymentDataRequest.fromJson(paymentDataRequestJson.get().toString());
        if (request != null) {
            AutoResolveHelper.resolveTask(
                    mPaymentsClient.loadPaymentData(request), this, LOAD_PAYMENT_DATA_REQUEST_CODE);
        }
    }

    /**
     * Handle a resolved activity from the Google Pay payment sheet
     *
     * @param requestCode the request code originally supplied to AutoResolveHelper in
     *     requestPayment()
     * @param resultCode the result code returned by the Google Pay API
     * @param data an Intent from the Google Pay API containing payment or error data
     * @see <a href="https://developer.android.com/training/basics/intents/result">Getting a result
     *     from an Activity</a>
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            // value passed in AutoResolveHelper
            case LOAD_PAYMENT_DATA_REQUEST_CODE:
                switch (resultCode) {
                    case Activity.RESULT_OK:
                        PaymentData paymentData = PaymentData.getFromIntent(data);
                        String json = paymentData.toJson();
                        // if using gateway tokenization, pass this token without modification
                        JSONObject paymentMethodData = null;
                        String paymentToken = null;
                        try {
                            paymentMethodData = new JSONObject(json)
                                    .getJSONObject("paymentMethodData");

                            paymentToken = paymentMethodData.getJSONObject("tokenizationData").getString("token");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        break;
                    case Activity.RESULT_CANCELED:
                        break;
                    case AutoResolveHelper.RESULT_ERROR:
                        Status status = AutoResolveHelper.getStatusFromIntent(data);
                        // Log the status for debugging.
                        // Generally, there is no need to show an error to the user.
                        // The Google Pay payment sheet will present any account errors.
                        break;
                    default:
                        // Do nothing.
                }
                break;
            default:
                // Do nothing.
        }
    }


    private void initializeGooglePayButton() {
        mGooglePayButton = findViewById(R.id.googlePayButtonID);
        mGooglePayButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//
//                updateBillObject();
//
//                Intent intent = new Intent(AssignPaymentsActivity.this, SelectPersonsActivity.class);
//                Intent intent = new Intent(AssignPaymentsActivity.this, MainActivity.class);
//
//                Bundle billBundle = bill.createBillBundle(getApplicationContext());
//                intent.putExtras(billBundle);
//                getApplicationContext().startActivity(intent);


            }
        });
    }

    private void getIntentData() {
        Bundle bundle = getIntent().getExtras();
        String billKey = getApplicationContext().getResources().getString(R.string.EXTRA_BILL_KEY);
        try {
            bill = bundle.getParcelable(billKey);
        } catch (Exception e) {
            Log.v("EXCEPTION", e.toString());
        }
    }

    private void initializePaymentsListView() {
        PreferencesController.clearPreferences(getApplicationContext());
        PreferencesController.saveSelectedPerson(getApplicationContext(), 0);
        paymentsListAdapter = new PaymentsAdapter(this, bill);
        paymentsListView = findViewById(R.id.assignPersonsListViewID);
        paymentsListView.setAdapter(paymentsListAdapter);
        paymentsListAdapter.notifyDataSetChanged();
    }

    private void updateBillObject() {
        Integer selectedPersonIndex = PreferencesController.getSelectedPerson(getApplicationContext());
        Person selectedPerson = bill.getPersonsList().get(selectedPersonIndex);

        Integer numberOfPayments = bill.getPaymentsList().size();
        List<Integer> selectedPaymentsLines = PreferencesController.getSelectedPayments(getApplicationContext(), numberOfPayments);
        List<Payment> paymentsList =  bill.getPaymentsList();
        for (Integer index : selectedPaymentsLines) {
            Payment selectedPayment = paymentsList.get(index);
            if (!bill.existPaymentInPaymentsToPerson(selectedPayment)) {
                PaymentToPerson paymentToPerson = new PaymentToPerson(selectedPayment, selectedPerson);
                bill.addPaymentToPerson(paymentToPerson);
            }
        }
    }
}
