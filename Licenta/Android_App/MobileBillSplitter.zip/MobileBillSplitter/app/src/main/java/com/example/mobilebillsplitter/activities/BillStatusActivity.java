package com.example.mobilebillsplitter.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import com.example.mobilebillsplitter.R;
import com.example.mobilebillsplitter.adapters.PaymentStatusAdapter;
import com.example.mobilebillsplitter.interfaces.OnDataReceive;

import java.util.List;

import ServerAPI.objects.Bill;
import ServerAPI.objects.Person;

public class BillStatusActivity extends AppCompatActivity implements OnDataReceive {
    private PaymentStatusAdapter listAdapter;
    private ListView listView;
    private Button homeButton;

    private Bill bill;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_bill_status);

        getSupportActionBar().setTitle("Bill status page");

        getIntentData();

//        initializeBill();

        initializeListView();

        initializeHomeButton();

    }

    private void initializeHomeButton() {
        homeButton = findViewById(R.id.billStatusHomeButtonID);
        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BillStatusActivity.this, MainActivity.class);
                Bundle billBundle = bill.createBillBundle(getApplicationContext());
                intent.putExtras(billBundle);
                startActivity(intent);
            }
        });
    }

    private void getIntentData() {
        Bundle bundle = getIntent().getExtras();
        String billKey = getApplicationContext().getResources().getString(R.string.EXTRA_BILL_KEY);
        bill = bundle.getParcelable(billKey);
    }

    private void initializeListView() {
        listAdapter = new PaymentStatusAdapter(this, bill);
        listView = findViewById(R.id.personsStatusListViewID);
        listView.setAdapter(listAdapter);
        listAdapter.notifyDataSetChanged();
    }
    // DETELE THIS
//    private void initializeBill() {
//        List<Person> personList = new ArrayList<>();
//        List<Payment> paymentsList = new ArrayList<>();
//
//        Person person1 = new Person("0000", "Cristi");
//        Person person2 = new Person("0002", "Cristi");
//        Person person3 = new Person("0003", "Cristi");
//        Person person4 = new Person("0004", "Cristi");
//        Person person5 = new Person("0005", "Cristi");
//        Person person6 = new Person("0006", "Cristi");
//        Person person7 = new Person("0007", "Cristi");
//        Person person8 = new Person("0008", "Cristi");
//        Person person9 = new Person("0009", "Cristi");
//        Person person10 = new Person("0009", "Cristi");
//
//
//        personList.add(person1);
//        personList.add(person2);
//        personList.add(person3);
//        personList.add(person4);
//        personList.add(person5);
//        personList.add(person6);
//        personList.add(person7);
//        personList.add(person8);
//        personList.add(person9);
//        personList.add(person10);
//
//
//        Payment payment1 = new Payment("product1", "price");
//        Payment payment2 = new Payment("product2", "price");
//        Payment payment3 = new Payment("product3", "price");
//        Payment payment4 = new Payment("product4", "price");
//        Payment payment5 = new Payment("product5", "price");
//        Payment payment6 = new Payment("product6", "price");
//        Payment payment7 = new Payment("product7", "price");
//        Payment payment8 = new Payment("product8", "price");
//        Payment payment9 = new Payment("product9", "price");
//        Payment payment10 = new Payment("product10", "price");
//        Payment payment11 = new Payment("product11", "price");
//        Payment payment12 = new Payment("product12", "price");
//        Payment payment13 = new Payment("product13", "price");
//        Payment payment14 = new Payment("product14", "price");
//        Payment payment15 = new Payment("product15", "price");
//
//
//        paymentsList.add(payment1);
//        paymentsList.add(payment2);
//        paymentsList.add(payment3);
//        paymentsList.add(payment4);
//        paymentsList.add(payment5);
//        paymentsList.add(payment6);
//        paymentsList.add(payment7);
//        paymentsList.add(payment8);
//        paymentsList.add(payment9);
//        paymentsList.add(payment10);
//        paymentsList.add(payment11);
//        paymentsList.add(payment12);
//        paymentsList.add(payment13);
//        paymentsList.add(payment14);
//        paymentsList.add(payment15);
//
//        bill = new Bill(paymentsList, personList, "title");
//    }

    @Override
    public void OnDataReceive(List<Person> personList) {

    }
}